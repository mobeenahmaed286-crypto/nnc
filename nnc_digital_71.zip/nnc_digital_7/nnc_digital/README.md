# NNC Digital — Multi-Page Publishing Hub

Enterprise-grade YouTube-to-Facebook stream automation hub. Manage multiple Facebook Pages concurrently, each mapped to its own YouTube source channel, independent publishing schedules, live queues, and automatic disk storage cleanup.

---

## 🌟 Key Features

1. **Multi-Page Command Center ("Total Pages" Section)**
   - Connect unlimited Facebook Pages independently.
   - Map each page to a specific YouTube Channel ID, handle (`@channel`), or URL.
   - Set custom upload schedules (daily/weekly, 24h run time, batch count per run).
   - Pause or resume automation per page without affecting others.

2. **Automated Storage Management & Cleanup**
   - **Zero Disk Waste**: Videos are automatically deleted from local storage immediately upon successful Facebook upload.
   - **Storage Optimizer Studio**: 1-click cache purge utility to clean leftover download files and reclaim disk space.

3. **Modern, Creative UI & Professional Workflow**
   - Sleek SaaS-grade dark theme built with high-craft Vanilla CSS & glassmorphism.
   - Global & Per-Page KPIs: Tracked videos, published count, pending queue, and storage saved (MB).
   - Filterable & searchable multi-page video stream queue with direct Facebook post links and detailed failure diagnostics.

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

> **Note**: For best video/audio merge quality, ensure `ffmpeg` is installed on your system.

### 2. Run the Dashboard
```bash
python app.py
```
Open your browser and visit: **`http://localhost:5000`**

### 3. Connect Your Facebook Pages
- Click **"+ Add New Page"** in the top navigation or dashboard.
- Enter your **Facebook Page ID**, **Page Access Token**, and **YouTube Channel Source** (`@handle`, Channel ID, or URL).
- Set your desired upload schedule and save!

### 4. Background Automated Scheduler
To run scheduled publishing in the background:
```bash
python scheduler.py
```

---

## 📁 File Structure
```
nnc_digital/
├── app.py                # Flask dashboard & multi-page management routes
├── pipeline.py           # Multi-page sync, publish cycle & auto-storage cleanup
├── scheduler.py          # Multi-page cron runner checking independent schedules
├── youtube_service.py    # YouTube Data API v3 channel resolver & video fetcher
├── downloader.py         # yt-dlp downloader with cookie & retry support
├── facebook_service.py   # Facebook Meta Graph API publisher & verification
├── db.py                 # SQLite database layer with multi-page & queue tracking
├── settings.py           # Global settings & storage path configuration
└── templates/
    ├── base.html         # Master layout with design system & Add Page modal
    ├── dashboard.html    # Main command center with "Total Pages" deck & queue
    ├── page_detail.html  # Single-page management, credentials & isolated queue
    └── settings.html     # Global API keys, Netscape cookies & Storage Optimizer
```
