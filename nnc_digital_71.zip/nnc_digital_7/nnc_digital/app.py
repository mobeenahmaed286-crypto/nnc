"""
NNC Digital - Multi-Page Automation Dashboard
Run: python app.py
Open: http://localhost:5000
"""
import os
import threading
import time
import logging
from functools import wraps
from dotenv import load_dotenv
load_dotenv()

from flask import Flask, render_template, redirect, url_for, flash, request, jsonify, session, send_from_directory
import db
import settings
import pipeline
import scheduler
import youtube_service
import facebook_service

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("nnc_app")

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "nnc-digital-luxury-enterprise-2026")

# Initialize SQLite database and settings
db.init_db()
settings.init_settings_table()

# =========================================================================
# ASSET SERVING ROUTES (Backgrounds & Media)
# =========================================================================

@app.route("/Asset/<path:filename>")
@app.route("/asset/<path:filename>")
@app.route("/assets/<path:filename>")
def serve_custom_assets(filename):
    asset_dir = os.path.join(os.path.dirname(__file__), "Asset")
    return send_from_directory(asset_dir, filename)


# =========================================================================
# AUTHENTICATION HOOKS & DECORATORS
# =========================================================================

@app.context_processor
def inject_user_context():
    """Injects current logged-in user and page quotas into all template contexts."""
    user_id = session.get("user_id")
    current_user = db.get_user_by_id(user_id) if user_id else None
    user_page_count = db.get_user_page_count(user_id) if user_id else 0
    return dict(
        current_user=current_user,
        user_page_count=user_page_count
    )


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login_route", next=request.url))
        user = db.get_user_by_id(session["user_id"])
        if not user or not user.get("is_active", 1):
            session.clear()
            flash("Session expired or account deactivated. Please log in again.", "error")
            return redirect(url_for("login_route"))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login_route", next=request.url))
        user = db.get_user_by_id(session["user_id"])
        if not user or user.get("role") != "admin":
            flash("Access denied. Super Admin privileges required.", "error")
            return redirect(url_for("home"))
        return f(*args, **kwargs)
    return decorated_function


# =========================================================================
# AUTO-START BACKGROUND SCHEDULER DAEMON
# =========================================================================
_scheduler_started = False

def _scheduler_background_loop():
    global _scheduler_started
    log.info("Background Auto-Scheduler is active and running.")
    while True:
        try:
            scheduler.check_and_execute_jobs()
        except Exception as e:
            log.error(f"Scheduler daemon encountered error: {e}")
        time.sleep(scheduler.CHECK_INTERVAL_SECONDS)


def init_auto_scheduler():
    global _scheduler_started
    if not _scheduler_started and (os.environ.get("WERKZEUG_RUN_MAIN") == "true" or not app.debug):
        thread = threading.Thread(target=_scheduler_background_loop, daemon=True, name="NNC_Background_Scheduler")
        thread.start()
        _scheduler_started = True
        log.info("Auto-scheduler thread initiated successfully.")

init_auto_scheduler()


# =========================================================================
# AUTHENTICATION ROUTES
# =========================================================================

@app.route("/login", methods=["GET", "POST"])
def login_route():
    if "user_id" in session and db.get_user_by_id(session["user_id"]):
        return redirect(url_for("home"))

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()
        
        user = db.verify_user_password(email, password)
        if user:
            session["user_id"] = user["id"]
            session["user_email"] = user["email"]
            session["user_role"] = user["role"]
            session["user_name"] = user["name"]
            
            db.log_activity(
                event_type="info",
                message=f"User '{user['name']}' ({user['email']}) logged in successfully."
            )
            flash(f"Welcome back, {user['name']}.", "success")
            
            next_url = request.args.get("next")
            return redirect(next_url or url_for("home"))
        else:
            flash("Invalid email address or password. Please verify your credentials.", "error")

    return render_template("login.html")


@app.route("/logout")
def logout_route():
    user_name = session.get("user_name", "User")
    session.clear()
    flash("Signed out successfully.", "info")
    return redirect(url_for("login_route"))


@app.route("/profile/change-password", methods=["POST"])
@login_required
def change_password_route():
    user_id = session["user_id"]
    new_password = request.form.get("new_password", "").strip()
    confirm_password = request.form.get("confirm_password", "").strip()

    if not new_password or len(new_password) < 6:
        flash("Password must be at least 6 characters long.", "error")
        return redirect(request.referrer or url_for("home"))

    if new_password != confirm_password:
        flash("New password and confirmation do not match.", "error")
        return redirect(request.referrer or url_for("home"))

    try:
        db.update_user_password(user_id, new_password)
        flash("Your password has been changed successfully.", "success")
    except Exception as e:
        flash(f"Could not update password: {e}", "error")

    return redirect(request.referrer or url_for("home"))


# =========================================================================
# ADMIN USER MANAGEMENT ROUTES
# =========================================================================

@app.route("/admin/users", methods=["GET"])
@admin_required
def admin_users_list():
    users = db.get_all_users()
    users_with_pages = []
    for u in users:
        u_dict = dict(u)
        user_pages = db.get_all_pages(user_id=u["id"])
        u_dict["pages"] = [
            {
                "id": p["id"],
                "page_name": p["page_name"],
                "yt_channel_id": p["yt_channel_id"],
                "yt_channel_name": p.get("yt_channel_name", ""),
                "fb_page_id": p["fb_page_id"],
                "is_active": p["is_active"]
            }
            for p in user_pages
        ]
        users_with_pages.append(u_dict)

    selected_user_id = request.args.get("user_id")
    selected_user = None
    if selected_user_id and selected_user_id.isdigit():
        selected_user = next((u for u in users_with_pages if u["id"] == int(selected_user_id)), None)

    all_pages = db.get_all_pages()
    return render_template(
        "admin_users.html",
        users=users_with_pages,
        selected_user=selected_user,
        all_pages_list=all_pages
    )


@app.route("/api/admin/users/<int:user_id>/pages", methods=["GET"])
@admin_required
def api_admin_user_pages(user_id):
    user = db.get_user_by_id(user_id)
    if not user:
        return jsonify({"success": False, "error": "User not found."}), 404
    pages = db.get_all_pages(user_id=user_id)
    return jsonify({
        "success": True,
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
            "page_limit": user["page_limit"]
        },
        "pages": [
            {
                "id": p["id"],
                "page_name": p["page_name"],
                "yt_channel_id": p["yt_channel_id"],
                "yt_channel_name": p.get("yt_channel_name", ""),
                "fb_page_id": p["fb_page_id"],
                "is_active": p["is_active"]
            }
            for p in pages
        ]
    })


@app.route("/admin/users/create", methods=["POST"])
@admin_required
def admin_create_user():
    email = request.form.get("email", "").strip().lower()
    name = request.form.get("name", "").strip()
    password = request.form.get("password", "").strip() or "123456"
    role = request.form.get("role", "user").strip().lower()
    page_limit = int(request.form.get("page_limit", 5) or 5)

    if not email:
        flash("User email address is required.", "error")
        return redirect(url_for("admin_users_list"))

    if not name:
        name = email.split("@")[0].capitalize()

    existing = db.get_user_by_email(email)
    if existing:
        flash(f"A user with email '{email}' already exists.", "error")
        return redirect(url_for("admin_users_list"))

    try:
        new_id = db.create_user(email=email, password=password, name=name, role=role, page_limit=page_limit)
        db.log_activity(
            event_type="info",
            message=f"Admin created new user account '{name}' ({email}) with page limit {page_limit}."
        )
        flash(f"User account '{email}' created successfully with initial password.", "success")
    except Exception as e:
        flash(f"Error creating user: {e}", "error")

    return redirect(url_for("admin_users_list"))


@app.route("/admin/users/<int:user_id>/password", methods=["POST"])
@admin_required
def admin_reset_user_password(user_id):
    new_password = request.form.get("new_password", "").strip()
    if not new_password or len(new_password) < 6:
        flash("Password must be at least 6 characters long.", "error")
        return redirect(url_for("admin_users_list"))

    target_user = db.get_user_by_id(user_id)
    if not target_user:
        flash("User not found.", "error")
        return redirect(url_for("admin_users_list"))

    try:
        db.update_user_password(user_id, new_password)
        db.log_activity(
            event_type="info",
            message=f"Admin reset password for user '{target_user['email']}'."
        )
        flash(f"Password for user '{target_user['email']}' has been updated.", "success")
    except Exception as e:
        flash(f"Could not reset password: {e}", "error")

    return redirect(url_for("admin_users_list"))


@app.route("/admin/users/<int:user_id>/edit", methods=["POST"])
@admin_required
def admin_edit_user(user_id):
    name = request.form.get("name", "").strip()
    role = request.form.get("role", "user").strip()
    page_limit = int(request.form.get("page_limit", 5) or 5)
    is_active = 1 if request.form.get("is_active") == "1" else 0

    try:
        db.update_user_details(user_id, name=name, role=role, page_limit=page_limit, is_active=is_active)
        flash("User details and page quota updated successfully.", "success")
    except Exception as e:
        flash(f"Error updating user: {e}", "error")

    return redirect(url_for("admin_users_list"))


@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@admin_required
def admin_delete_user(user_id):
    if user_id == session.get("user_id"):
        flash("You cannot delete your own admin account.", "error")
        return redirect(url_for("admin_users_list"))

    target_user = db.get_user_by_id(user_id)
    try:
        db.delete_user(user_id)
        flash(f"User '{target_user['email'] if target_user else user_id}' deleted successfully.", "success")
    except Exception as e:
        flash(f"Could not delete user: {e}", "error")

    return redirect(url_for("admin_users_list"))


# =========================================================================
# FLASK WEB DASHBOARD ROUTES
# =========================================================================

@app.route("/")
@login_required
def home():
    user_id = session.get("user_id")
    current_user = db.get_user_by_id(user_id)
    is_admin = current_user.get("role") == "admin"

    # For Super Admin: Show Users Directory directly as primary home
    if is_admin:
        return admin_users_list()

    # For Standard Users: Show their personal workspace
    scoped_user_id = user_id
    all_pages = db.get_all_pages(user_id=scoped_user_id)

    all_users_list = db.get_all_users() if is_admin else []

    # Compute stats for scoped pages
    tracked_count = 0
    published_count = 0
    pending_count = 0
    failed_count = 0
    in_prog_count = 0
    storage_saved_mb = 0.0

    pages_with_schedule = []
    for p in all_pages:
        p_stats = db.get_page_stats(p["id"])
        tracked_count += p_stats["tracked"]
        published_count += p_stats["published"]
        pending_count += p_stats["pending"]
        failed_count += p_stats["failed"]
        in_prog_count += p_stats.get("in_progress", 0)
        storage_saved_mb += p_stats["storage_saved_mb"]

        p_copy = dict(p)
        p_copy["stats"] = p_stats
        p_copy["schedule_info"] = scheduler.calculate_next_run(p)
        pages_with_schedule.append(p_copy)

    stats = {
        "total_pages": len(all_pages),
        "active_pages": len([p for p in all_pages if p.get("is_active")]),
        "tracked": tracked_count,
        "published": published_count,
        "pending": pending_count,
        "failed": failed_count,
        "in_progress": in_prog_count,
        "storage_saved_mb": round(storage_saved_mb, 2)
    }

    storage_info = pipeline.get_storage_usage()
    
    # Query parameters for filtering video queue
    selected_page_id = request.args.get("page_id", "all")
    selected_status = request.args.get("status", "all")
    search_query = request.args.get("q", "").strip()

    videos = db.get_all_videos(
        status=selected_status if selected_status != "all" else None,
        page_id=int(selected_page_id) if selected_page_id != "all" and selected_page_id.isdigit() else None,
        user_id=scoped_user_id,
        search=search_query if search_query else None,
        limit=200
    )

    top_videos = db.get_global_top_performing_videos(user_id=scoped_user_id, limit=6)
    recent_activity = db.get_recent_activity(limit=30)

    return render_template(
        "dashboard.html",
        stats=stats,
        storage=storage_info,
        pages=pages_with_schedule,
        all_pages_list=all_pages,
        all_users_list=[],
        selected_user_filter="all",
        videos=videos,
        selected_page_id=selected_page_id,
        selected_status=selected_status,
        search_query=search_query,
        recent_activity=recent_activity
    )





@app.route("/pages/<int:page_id>")
@login_required
def page_detail(page_id):
    user_id = session.get("user_id")
    current_user = db.get_user_by_id(user_id)
    page_stats = db.get_page_stats(page_id)
    if not page_stats:
        flash("Page not found.", "error")
        return redirect(url_for("home"))

    # Enforce page ownership for regular users
    if current_user.get("role") != "admin" and page_stats["page"].get("user_id") != user_id:
        flash("Access denied. You do not have permission to view or manage this page.", "error")
        return redirect(url_for("home"))

    status_filter = request.args.get("status", "all")
    videos = db.get_videos_for_page(page_id, status=status_filter if status_filter != "all" else None, limit=150)
    
    # Calculate schedule information
    schedule_info = scheduler.calculate_next_run(page_stats["page"])

    # Fetch Latest 10 Channel Videos directly from YouTube
    latest_videos = []
    latest_fetch_error = None
    try:
        latest_videos = pipeline.fetch_page_latest_videos_with_status(page_id, limit=10)
    except Exception as e:
        latest_fetch_error = str(e)
        log.warning(f"Could not load latest videos for page {page_id}: {e}")

    # Fetch Popular (Most Viewed) 10 Channel Videos directly from YouTube
    popular_videos = []
    popular_fetch_error = None
    try:
        popular_videos = pipeline.fetch_page_popular_videos_with_status(page_id, limit=10)
    except Exception as e:
        popular_fetch_error = str(e)
        log.warning(f"Could not load popular videos for page {page_id}: {e}")

    # Top performing videos for this page
    top_page_videos = db.get_page_top_performing_videos(page_id, limit=6)

    # Test FB connection live
    fb_status = facebook_service.verify_page_access(
        page_stats["page"]["fb_page_id"],
        page_stats["page"]["fb_page_access_token"]
    )

    scoped_user_id = None if current_user.get("role") == "admin" else user_id
    all_pages = db.get_all_pages(user_id=scoped_user_id)
    recent_activity = db.get_recent_activity(page_id=page_id, limit=25)

    return render_template(
        "page_detail.html",
        page=page_stats["page"],
        stats=page_stats,
        videos=videos,
        latest_videos=latest_videos,
        latest_fetch_error=latest_fetch_error,
        popular_videos=popular_videos,
        popular_fetch_error=popular_fetch_error,
        top_page_videos=top_page_videos,
        schedule_info=schedule_info,
        fb_status=fb_status,
        status_filter=status_filter,
        all_pages_list=all_pages,
        recent_activity=recent_activity
    )


@app.route("/pages/add", methods=["POST"])
@login_required
def add_page_route():
    user_id = session.get("user_id")
    current_user = db.get_user_by_id(user_id)

    # Enforce page quota
    if not db.can_user_add_page(user_id):
        flash(f"Page limit reached ({current_user.get('page_limit', 5)} pages max). Please contact Super Admin to increase your quota.", "error")
        return redirect(url_for("home"))

    page_name = request.form.get("page_name", "").strip()
    fb_page_id = request.form.get("fb_page_id", "").strip()
    fb_token = request.form.get("fb_page_access_token", "").strip()
    yt_source = request.form.get("yt_channel_source", "").strip()
    yt_api_key = request.form.get("yt_api_key", "").strip()
    upload_mode = request.form.get("upload_mode", "daily").strip()
    
    # Handle AM/PM or direct run_time
    run_time = request.form.get("run_time", "").strip()
    run_time_hour = request.form.get("run_time_hour", "").strip()
    run_time_min = request.form.get("run_time_min", "").strip()
    run_time_period = request.form.get("run_time_period", "AM").strip()

    if run_time_hour and run_time_min:
        run_time = f"{run_time_hour.zfill(2)}:{run_time_min.zfill(2)} {run_time_period}"
    elif not run_time:
        run_time = "09:00 AM"

    uploads_per_run = int(request.form.get("uploads_per_run", 1) or 1)
    posts_per_day = int(request.form.get("posts_per_day", 1) or 1)
    post_gap_minutes = int(request.form.get("post_gap_minutes", 120) or 120)
    start_time = request.form.get("start_time", "09:00 AM").strip() or "09:00 AM"
    end_time = request.form.get("end_time", "10:00 PM").strip() or "10:00 PM"
    auto_delete_file = 1 if request.form.get("auto_delete_file") == "1" else 0

    if not fb_page_id or not fb_token:
        flash("Facebook Page ID and Page Access Token are required.", "error")
        return redirect(url_for("home"))

    if not yt_source:
        flash("YouTube Channel Source (Channel ID, Handle, or URL) is required.", "error")
        return redirect(url_for("home"))

    # Resolve YouTube Channel metadata
    yt_channel_id = yt_source
    yt_channel_name = page_name
    try:
        res = youtube_service.resolve_channel(yt_source, api_key=yt_api_key or None)
        yt_channel_id = res.get("channel_id", yt_source)
        if res.get("channel_title"):
            yt_channel_name = res.get("channel_title")
    except Exception as e:
        yt_channel_id = yt_source

    # Auto-resolve token if User Token was passed instead of Page Token
    fb_token = facebook_service.resolve_page_token(fb_page_id, fb_token)

    # Auto-resolve page name if blank from Facebook Graph API
    if not page_name:
        try:
            fb_check = facebook_service.verify_page_access(fb_page_id, fb_token)
            if fb_check.get("valid") and fb_check.get("name"):
                page_name = fb_check.get("name")
            else:
                page_name = f"Page {fb_page_id}"
        except Exception:
            page_name = f"Page {fb_page_id}"

    try:
        new_page_id = db.add_page(
            page_name=page_name,
            fb_page_id=fb_page_id,
            fb_page_access_token=fb_token,
            yt_channel_id=yt_channel_id,
            yt_channel_name=yt_channel_name,
            yt_api_key=yt_api_key,
            upload_mode=upload_mode,
            run_time=run_time,
            uploads_per_run=uploads_per_run,
            posts_per_day=posts_per_day,
            post_gap_minutes=post_gap_minutes,
            start_time=start_time,
            end_time=end_time,
            auto_delete_file=auto_delete_file,
            user_id=user_id
        )
        db.log_activity(
            page_id=new_page_id,
            page_name=page_name,
            event_type="info",
            message=f"Connected Facebook page '{page_name}' with YouTube channel '{yt_channel_name}'."
        )
        flash(f"Successfully connected page '{page_name}'.", "success")
        return redirect(url_for("page_detail", page_id=new_page_id))
    except Exception as e:
        flash(f"Could not create page: {e}", "error")
        return redirect(url_for("home"))


@app.route("/pages/<int:page_id>/sync-engagement", methods=["POST"])
@login_required
def sync_page_engagement_route(page_id):
    try:
        updated = facebook_service.sync_page_video_metrics(page_id)
        flash(f"Refreshed engagement metrics for {updated} published video(s).", "success")
    except Exception as e:
        flash(f"Could not refresh engagement metrics: {e}", "error")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))



@app.route("/pages/import-bulk", methods=["POST"])
def import_bulk_pages():
    """
    Accepts multiple discovered Facebook pages linked to one User Token,
    each with its own configured YouTube channel source, and saves them all at once.
    """
    data = request.get_json() or {}
    pages_to_import = data.get("pages", [])

    if not pages_to_import:
        return jsonify({"success": False, "error": "No pages selected for import."}), 400

    imported_count = 0
    errors = []

    for item in pages_to_import:
        fb_page_id = str(item.get("page_id", "")).strip()
        page_name = item.get("page_name", "").strip() or f"Page {fb_page_id}"
        fb_token = item.get("page_token", "").strip()
        yt_source = item.get("yt_source", "").strip()
        upload_mode = item.get("upload_mode", "daily")
        run_time = item.get("run_time", "09:00 AM")
        uploads_per_run = int(item.get("uploads_per_run", 1) or 1)
        auto_delete = int(item.get("auto_delete_file", 1))

        if not fb_page_id or not fb_token:
            continue

        # Resolve YouTube Channel source
        yt_channel_id = yt_source
        yt_channel_name = page_name
        if yt_source:
            try:
                res = youtube_service.resolve_channel(yt_source)
                yt_channel_id = res.get("channel_id", yt_source)
                if res.get("channel_title"):
                    yt_channel_name = res.get("channel_title")
            except Exception:
                yt_channel_id = yt_source

        # Ensure valid page access token
        effective_token = facebook_service.resolve_page_token(fb_page_id, fb_token)

        try:
            p_id = db.add_page(
                page_name=page_name,
                fb_page_id=fb_page_id,
                fb_page_access_token=effective_token,
                yt_channel_id=yt_channel_id,
                yt_channel_name=yt_channel_name,
                upload_mode=upload_mode,
                run_time=run_time,
                uploads_per_run=uploads_per_run,
                auto_delete_file=auto_delete
            )
            db.log_activity(
                page_id=p_id,
                page_name=page_name,
                event_type="info",
                message=f"🎉 Bulk imported page '{page_name}'."
            )
            imported_count += 1
        except Exception as e:
            errors.append(f"{page_name}: {str(e)}")

    if imported_count > 0:
        flash(f"Successfully connected {imported_count} Facebook page(s) to automation!", "success")
        return jsonify({"success": True, "count": imported_count, "errors": errors})
    else:
        return jsonify({"success": False, "error": "; ".join(errors) or "Failed to import pages."}), 400


@app.route("/pages/<int:page_id>/edit", methods=["POST"])
@login_required
def edit_page(page_id):
    user_id = session.get("user_id")
    current_user = db.get_user_by_id(user_id)
    page = db.get_page_by_id(page_id)
    if not page:
        flash("Page not found.", "error")
        return redirect(url_for("home"))

    if current_user.get("role") != "admin" and page.get("user_id") != user_id:
        flash("Access denied.", "error")
        return redirect(url_for("home"))

    page_name = request.form.get("page_name", "").strip()
    fb_page_id = request.form.get("fb_page_id", "").strip()
    fb_token = request.form.get("fb_page_access_token", "").strip()
    yt_channel_id = request.form.get("yt_channel_id", "").strip()
    yt_channel_name = request.form.get("yt_channel_name", "").strip()
    yt_api_key = request.form.get("yt_api_key", "").strip()
    upload_mode = request.form.get("upload_mode", "daily").strip()

    # Handle AM/PM or direct run_time
    run_time = request.form.get("run_time", "").strip()
    run_time_hour = request.form.get("run_time_hour", "").strip()
    run_time_min = request.form.get("run_time_min", "").strip()
    run_time_period = request.form.get("run_time_period", "AM").strip()

    if run_time_hour and run_time_min:
        run_time = f"{run_time_hour.zfill(2)}:{run_time_min.zfill(2)} {run_time_period}"
    elif not run_time:
        run_time = "09:00 AM"

    uploads_per_run = int(request.form.get("uploads_per_run", 1) or 1)
    posts_per_day = int(request.form.get("posts_per_day", 1) or 1)
    post_gap_minutes = int(request.form.get("post_gap_minutes", 120) or 120)
    start_time = request.form.get("start_time", "09:00 AM").strip() or "09:00 AM"
    end_time = request.form.get("end_time", "10:00 PM").strip() or "10:00 PM"
    auto_delete_file = 1 if request.form.get("auto_delete_file") == "1" else 0

    # Auto-resolve token if User Token was passed
    fb_token = facebook_service.resolve_page_token(fb_page_id, fb_token)

    fields = {
        "page_name": page_name,
        "fb_page_id": fb_page_id,
        "fb_page_access_token": fb_token,
        "yt_channel_id": yt_channel_id,
        "yt_channel_name": yt_channel_name,
        "yt_api_key": yt_api_key,
        "upload_mode": upload_mode,
        "run_time": run_time,
        "uploads_per_run": uploads_per_run,
        "posts_per_day": posts_per_day,
        "post_gap_minutes": post_gap_minutes,
        "start_time": start_time,
        "end_time": end_time,
        "auto_delete_file": auto_delete_file,
    }

    db.update_page(page_id, **fields)
    db.log_activity(
        page_id=page_id,
        page_name=page_name,
        event_type="info",
        message=f"Updated configuration for '{page_name}' (Schedule: {scheduler.format_time_display(run_time)})."
    )
    flash(f"Settings updated for '{page_name}'.", "success")
    return redirect(url_for("page_detail", page_id=page_id))


@app.route("/pages/<int:page_id>/toggle", methods=["POST"])
@login_required
def toggle_page(page_id):
    db.toggle_page_status(page_id)
    page = db.get_page_by_id(page_id)
    state = "activated" if page and page["is_active"] else "paused"
    db.log_activity(
        page_id=page_id,
        page_name=page["page_name"] if page else "",
        event_type="info",
        message=f"Page automation is now {state.upper()}."
    )
    flash(f"Page automation is now {state}.", "info")
    return redirect(request.referrer or url_for("home"))


@app.route("/pages/<int:page_id>/delete", methods=["POST"])
@login_required
def delete_page_route(page_id):
    user_id = session.get("user_id")
    current_user = db.get_user_by_id(user_id)
    page = db.get_page_by_id(page_id)
    if not page:
        flash("Page not found.", "error")
        return redirect(url_for("home"))

    if current_user.get("role") != "admin" and page.get("user_id") != user_id:
        flash("Access denied.", "error")
        return redirect(url_for("home"))

    page_name = page["page_name"]
    db.delete_page(page_id)
    db.log_activity(
        page_id=None,
        page_name=page_name,
        event_type="info",
        message=f"Removed page '{page_name}' and cleared its queue."
    )
    flash(f"Deleted page '{page_name}' and its queued records.", "info")
    return redirect(url_for("home"))



@app.route("/pages/<int:page_id>/sync", methods=["POST"])
@login_required
def sync_single_page(page_id):
    try:
        total, new_queued = pipeline.sync_page_youtube(page_id)
        flash(f"YouTube sync complete. {total} channel videos scanned, {new_queued} new videos queued.", "success")
    except Exception as e:
        flash(f"YouTube sync failed: {e}", "error")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))


@app.route("/pages/<int:page_id>/fetch-latest", methods=["GET", "POST"])
@login_required
def fetch_latest_page_videos_route(page_id):
    try:
        latest = pipeline.fetch_page_latest_videos_with_status(page_id, limit=10)
        flash(f"Fetched latest {len(latest)} videos from YouTube channel successfully.", "success")
    except Exception as e:
        flash(f"Could not fetch latest videos: {e}", "error")
    return redirect(url_for("page_detail", page_id=page_id, tab="latest"))


@app.route("/pages/<int:page_id>/fetch-popular", methods=["GET", "POST"])
@login_required
def fetch_popular_page_videos_route(page_id):
    try:
        popular = pipeline.fetch_page_popular_videos_with_status(page_id, limit=10)
        flash(f"Fetched top {len(popular)} popular (most viewed) videos from YouTube channel successfully.", "success")
    except Exception as e:
        flash(f"Could not fetch popular videos: {e}", "error")
    return redirect(url_for("page_detail", page_id=page_id, tab="popular"))


@app.route("/pages/<int:page_id>/publish", methods=["POST"])
@login_required
def publish_single_page(page_id):
    try:
        results = pipeline.run_publish_cycle_for_page(page_id)
        if not results:
            flash("No pending videos in queue for this page.", "info")
        else:
            published_count = len([r for r in results if r.get("status") == "published"])
            failed_count = len([r for r in results if r.get("status") == "failed"])
            if published_count > 0:
                flash(f"Published {published_count} video(s) to Facebook successfully.", "success")
            if failed_count > 0:
                flash(f"{failed_count} video(s) failed. Check details below.", "error")
    except Exception as e:
        flash(f"Publish cycle error: {e}", "error")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))


@app.route("/pages/<int:page_id>/retry", methods=["POST"])
@login_required
def retry_page_failed(page_id):
    try:
        count = db.retry_failed_videos(page_id)
        if count > 0:
            db.log_activity(
                page_id=page_id,
                event_type="queue",
                message=f"Moved {count} failed video(s) back to queue for retry."
            )
            flash(f"Moved {count} failed video(s) back to queue for retry.", "success")
        else:
            flash("No failed videos to retry.", "info")
    except Exception as e:
        flash(f"Retry error: {e}", "error")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))


@app.route("/pages/<int:page_id>/clear-logs", methods=["POST"])
@login_required
def clear_page_logs_route(page_id):
    db.clear_activity_logs(page_id)
    flash("Activity logs cleared.", "info")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))


# =========================================================================
# RE-QUEUE / RESCHEDULE & ON-DEMAND PUBLISH ROUTES
# =========================================================================

@app.route("/pages/<int:page_id>/videos/<video_id>/queue", methods=["POST"])
@login_required
def queue_specific_video_route(page_id, video_id):
    """Adds a specific video from Latest/Popular Videos into the pending queue."""
    title = request.form.get("title", f"Video {video_id}").strip()
    pub_at = request.form.get("published_at", "").strip()
    try:
        is_new = db.upsert_single_video(page_id, video_id, title, pub_at)
        page = db.get_page_by_id(page_id)
        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"] if page else "",
            video_id=video_id,
            video_title=title,
            event_type="queue",
            message=f"Added '{title}' to upload queue."
        )
        flash(f"Video '{title}' added to pending queue.", "success")
    except Exception as e:
        flash(f"Failed to queue video: {e}", "error")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))


@app.route("/pages/<int:page_id>/videos/<video_id>/requeue", methods=["POST"])
@login_required
def requeue_single_video_route(page_id, video_id):
    """Resets an individual video status back to 'new' so it will be rescheduled."""
    try:
        db.requeue_video(page_id, video_id)
        page = db.get_page_by_id(page_id)
        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"] if page else "",
            video_id=video_id,
            event_type="queue",
            message=f"Re-queued video {video_id} for scheduled publishing."
        )
        flash(f"Video {video_id} has been re-queued and rescheduled for publishing.", "success")
    except Exception as e:
        flash(f"Failed to re-queue video: {e}", "error")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))


@app.route("/pages/<int:page_id>/videos/<video_id>/publish-now", methods=["POST"])
@login_required
def publish_specific_video_route(page_id, video_id):
    """Directly triggers an immediate download & upload of a specific video."""
    title = request.form.get("title", f"Video {video_id}").strip()
    pub_at = request.form.get("published_at", "").strip()
    
    # Ensure video exists in database first
    db.upsert_single_video(page_id, video_id, title, pub_at)

    try:
        res = pipeline.publish_single_video(page_id, video_id)
        flash(f"Video successfully uploaded to Facebook! Post ID: {res['fb_post_id']} (Freed {res['file_size_mb']} MB)", "success")
    except Exception as e:
        flash(f"Publish failed for video {video_id}: {e}", "error")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))


@app.route("/pages/<int:page_id>/requeue-all", methods=["POST"])
@login_required
def requeue_all_page_videos_route(page_id):
    """Resets all videos for a page back to 'new' queue for full rescheduling."""
    try:
        count = db.requeue_all_page_videos(page_id, only_published=False)
        db.log_activity(
            page_id=page_id,
            event_type="queue",
            message=f"Rescheduled all {count} videos back to pending queue."
        )
        flash(f"All {count} videos for this page have been rescheduled and added back to pending queue.", "success")
    except Exception as e:
        flash(f"Failed to reschedule videos: {e}", "error")
    return redirect(request.referrer or url_for("page_detail", page_id=page_id))


@app.route("/sync-all", methods=["POST"])
@login_required
def sync_all():
    try:
        summary = pipeline.sync_all_active_pages()
        total_new = sum(item.get("new", 0) for item in summary if item.get("success"))
        flash(f"All active pages synced successfully. {total_new} new video(s) queued across all pages.", "success")
    except Exception as e:
        flash(f"Sync all error: {e}", "error")
    return redirect(url_for("home"))


@app.route("/publish-all", methods=["POST"])
@login_required
def publish_all():
    try:
        results = pipeline.run_publish_cycle_all()
        if not results:
            flash("No pending videos across active pages.", "info")
        else:
            published_count = len([r for r in results if r.get("status") == "published"])
            flash(f"Published {published_count} video(s) across all active pages.", "success")
    except Exception as e:
        flash(f"Publish all error: {e}", "error")
    return redirect(url_for("home"))


@app.route("/storage/clean", methods=["POST"])
@login_required
def clean_storage_route():
    try:
        res = pipeline.clean_storage()
        flash(f"Storage cleanup complete: Removed {res['deleted_count']} file(s) and reclaimed {res['reclaimed_mb']} MB of disk space.", "success")
    except Exception as e:
        flash(f"Storage clean failed: {e}", "error")
    return redirect(request.referrer or url_for("home"))


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings_page():
    if request.method == "POST":
        values = {
            "YOUTUBE_API_KEY": request.form.get("YOUTUBE_API_KEY", "").strip(),
            "YOUTUBE_COOKIES": request.form.get("YOUTUBE_COOKIES", "").strip(),
            "DOWNLOAD_DIR": request.form.get("DOWNLOAD_DIR", "./downloads").strip(),
        }
        settings.set_many(values)
        flash("Global settings saved successfully.", "success")
        return redirect(url_for("settings_page"))

    current = settings.get_all()
    storage_info = pipeline.get_storage_usage()
    all_pages = db.get_all_pages()
    return render_template("settings.html", s=current, storage=storage_info, all_pages_list=all_pages)


# =========================================================================
# REAL-TIME LIVE DATA & API ENDPOINTS
# =========================================================================

@app.route("/api/live-status", methods=["GET"])
@login_required
def api_live_status():
    """
    Returns real-time global metrics, current active jobs, and recent activity logs.
    """
    user_id = session.get("user_id")
    current_user = db.get_user_by_id(user_id)
    is_admin = current_user.get("role") == "admin"
    scoped_user_id = None if is_admin else user_id

    global_stats = db.get_global_stats()
    storage_info = pipeline.get_storage_usage()
    recent_events = db.get_live_events_buffer(limit=25)
    
    return jsonify({
        "success": True,
        "timestamp": time.time(),
        "stats": {
            "total_pages": global_stats.get("total_pages", 0),
            "active_pages": global_stats.get("active_pages", 0),
            "tracked": global_stats.get("tracked", 0),
            "published": global_stats.get("published", 0),
            "pending": global_stats.get("pending", 0),
            "failed": global_stats.get("failed", 0),
            "in_progress": global_stats.get("in_progress", 0),
            "storage_saved_mb": global_stats.get("storage_saved_mb", 0.0),
        },
        "storage": storage_info,
        "recent_events": recent_events
    })


@app.route("/api/pages/<int:page_id>/live-status", methods=["GET"])
@login_required
def api_page_live_status(page_id):
    """
    Returns page-specific live metrics, video queue items, and activity logs.
    """
    page_stats = db.get_page_stats(page_id)
    if not page_stats:
        return jsonify({"success": False, "error": "Page not found."}), 404

    status_filter = request.args.get("status", "all")
    videos = db.get_videos_for_page(page_id, status=status_filter if status_filter != "all" else None, limit=100)
    schedule_info = scheduler.calculate_next_run(page_stats["page"])
    recent_events = db.get_recent_activity(page_id=page_id, limit=20)

    return jsonify({
        "success": True,
        "page_id": page_id,
        "stats": page_stats,
        "schedule": schedule_info,
        "video_count": len(videos),
        "recent_events": recent_events
    })


@app.route("/api/pages/<int:page_id>/latest-videos", methods=["GET"])
@login_required
def api_page_latest_videos(page_id):
    """
    Returns the 10 newest videos from the page's YouTube channel with live status mapping.
    """
    try:
        latest = pipeline.fetch_page_latest_videos_with_status(page_id, limit=10)
        return jsonify({"success": True, "videos": latest})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400


@app.route("/api/pages/<int:page_id>/popular-videos", methods=["GET"])
@login_required
def api_page_popular_videos(page_id):
    """
    Returns the 10 most popular / highest-viewed videos from the page's YouTube channel with live status mapping.
    """
    try:
        popular = pipeline.fetch_page_popular_videos_with_status(page_id, limit=10)
        return jsonify({"success": True, "videos": popular})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400


@app.route("/api/pages/<int:page_id>/queue-video", methods=["POST"])
@login_required
def api_queue_video(page_id):
    """
    AJAX endpoint to add or re-queue an individual video.
    """
    data = request.get_json() or {}
    video_id = data.get("video_id", "").strip()
    title = data.get("title", f"Video {video_id}").strip()
    published_at = data.get("published_at", "").strip()

    if not video_id:
        return jsonify({"success": False, "error": "Video ID is required."}), 400

    try:
        is_new = db.upsert_single_video(page_id, video_id, title, published_at)
        page = db.get_page_by_id(page_id)
        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"] if page else "",
            video_id=video_id,
            video_title=title,
            event_type="queue",
            message=f"Added '{title}' to upload queue."
        )
        return jsonify({"success": True, "is_new": is_new, "message": "Video queued successfully."})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400


@app.route("/api/discover-pages", methods=["POST"])
@login_required
def api_discover_pages():
    """
    Given a single User Token, scans all managed pages, retrieves their Page Tokens,
    and flags which ones are already added into the database.
    """
    data = request.get_json() or {}
    user_token = data.get("user_access_token", "").strip()
    if not user_token:
        return jsonify({"success": False, "error": "User Access Token is required."}), 400

    try:
        pages = facebook_service.list_pages(user_token)
        existing_page_ids = {str(p["fb_page_id"]) for p in db.get_all_pages()}
        
        enhanced_pages = []
        for p in pages:
            enhanced_pages.append({
                "id": str(p["id"]),
                "name": p["name"],
                "access_token": p["access_token"],
                "category": p.get("category", "General"),
                "picture": p.get("picture", ""),
                "already_connected": str(p["id"]) in existing_page_ids
            })

        return jsonify({"success": True, "pages": enhanced_pages})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400


@app.route("/api/verify-channel", methods=["POST"])
@login_required
def api_verify_channel():
    data = request.get_json() or {}
    source = data.get("source", "").strip()
    api_key = data.get("api_key", "").strip() or None
    if not source:
        return jsonify({"success": False, "error": "Source is required."}), 400

    try:
        info = youtube_service.resolve_channel(source, api_key=api_key)
        return jsonify({"success": True, "data": info})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400


@app.route("/api/verify-facebook", methods=["POST"])
@login_required
def api_verify_facebook():
    data = request.get_json() or {}
    page_id = data.get("page_id", "").strip()
    token = data.get("token", "").strip()
    if not page_id or not token:
        return jsonify({"success": False, "error": "Page ID and Token are required."}), 400

    info = facebook_service.verify_page_access(page_id, token)
    return jsonify(info)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)


