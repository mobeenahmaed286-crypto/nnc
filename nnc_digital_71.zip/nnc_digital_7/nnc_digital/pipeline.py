"""
Core multi-page publishing pipeline:
1. sync_page_youtube(page_id)        -> pulls page's designated YT channel videos into local DB
2. run_publish_cycle_for_page(page_id)-> downloads batch, publishes to Facebook, and AUTO-DELETES local files
3. publish_single_video(page_id, video_id) -> manually publishes a specific video on demand with auto-cleanup
4. Global triggers: sync_all_active_pages(), run_publish_cycle_all()
5. Storage Manager: clean_storage(), get_storage_usage()
"""
import os
import glob
import logging
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

import db
import settings
import youtube_service
import downloader
import facebook_service

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("nnc_digital")


def sync_page_youtube(page_id: int):
    """
    Syncs videos from the YouTube channel associated with this page.
    """
    page = db.get_page_by_id(page_id)
    if not page:
        raise ValueError(f"Page ID {page_id} not found.")

    channel_id = page.get("yt_channel_id")
    if not channel_id:
        raise ValueError(f"No YouTube Channel configured for page '{page['page_name']}'.")

    api_key = page.get("yt_api_key") or None
    log.info(f"Syncing YouTube videos for page '{page['page_name']}' (Channel: {channel_id})...")

    db.log_activity(
        page_id=page_id,
        page_name=page["page_name"],
        event_type="sync",
        message=f"🔄 Scanning YouTube channel '{page.get('yt_channel_name') or channel_id}' for new videos..."
    )

    try:
        videos = youtube_service.list_channel_videos(channel_id=channel_id, api_key=api_key, max_results=100)
        
        new_count = 0
        conn = db.get_conn()
        for v in videos:
            existing = conn.execute(
                "SELECT 1 FROM videos WHERE page_id = ? AND video_id = ?",
                (page_id, v["video_id"])
            ).fetchone()
            
            db.upsert_page_video(page_id, v["video_id"], v["title"], v["published_at"])
            if not existing:
                new_count += 1
        conn.close()

        now = datetime.utcnow().isoformat()
        db.update_page(page_id, last_sync_at=now)

        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"],
            event_type="success",
            message=f"✅ Sync complete: {len(videos)} total videos on channel, {new_count} newly added to queue."
        )

        log.info(f"Sync complete for '{page['page_name']}': {len(videos)} total on channel, {new_count} newly queued.")
        return len(videos), new_count

    except Exception as e:
        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"],
            event_type="error",
            message=f"❌ YouTube sync failed for '{page['page_name']}': {str(e)}"
        )
        raise


def fetch_page_latest_videos_with_status(page_id: int, limit: int = 10):
    """
    Fetches the top N (default 10) latest videos from the page's YouTube channel
    and cross-references each video with local DB to attach queue/publish status.
    """
    page = db.get_page_by_id(page_id)
    if not page:
        raise ValueError(f"Page ID {page_id} not found.")

    channel_id = page.get("yt_channel_id")
    if not channel_id:
        return []

    api_key = page.get("yt_api_key") or None
    raw_videos = youtube_service.fetch_latest_channel_videos(channel_id, api_key=api_key, max_results=limit)

    if not raw_videos:
        return []

    video_ids = [v["video_id"] for v in raw_videos]
    status_map = db.get_video_status_map(page_id, video_ids)

    enriched = []
    for v in raw_videos:
        vid = v["video_id"]
        db_record = status_map.get(vid)
        
        status = db_record["status"] if db_record else "not_queued"
        fb_post_id = db_record.get("fb_post_id") if db_record else None
        error_msg = db_record.get("error_message") if db_record else None

        enriched.append({
            "video_id": vid,
            "title": v.get("title", f"Video {vid}"),
            "published_at": v.get("published_at", ""),
            "thumbnail": v.get("thumbnail") or f"https://img.youtube.com/vi/{vid}/mqdefault.jpg",
            "url": v.get("url") or f"https://www.youtube.com/watch?v={vid}",
            "channel_title": v.get("channel_title", page.get("yt_channel_name", "")),
            "status": status,
            "fb_post_id": fb_post_id,
            "error_message": error_msg,
            "is_in_queue": status in ("new", "queued", "downloaded"),
            "is_published": status == "published",
            "is_failed": status == "failed"
        })

    return enriched


def fetch_page_popular_videos_with_status(page_id: int, limit: int = 10):
    """
    Fetches the top N (default 10) most popular / highest-viewed videos from the page's YouTube channel
    and cross-references each video with local DB to attach queue/publish status.
    """
    page = db.get_page_by_id(page_id)
    if not page:
        raise ValueError(f"Page ID {page_id} not found.")

    channel_id = page.get("yt_channel_id")
    if not channel_id:
        return []

    api_key = page.get("yt_api_key") or None
    raw_videos = youtube_service.fetch_popular_channel_videos(channel_id, api_key=api_key, max_results=limit)

    if not raw_videos:
        return []

    video_ids = [v["video_id"] for v in raw_videos]
    status_map = db.get_video_status_map(page_id, video_ids)

    enriched = []
    for v in raw_videos:
        vid = v["video_id"]
        db_record = status_map.get(vid)
        
        status = db_record["status"] if db_record else "not_queued"
        fb_post_id = db_record.get("fb_post_id") if db_record else None
        error_msg = db_record.get("error_message") if db_record else None

        enriched.append({
            "video_id": vid,
            "title": v.get("title", f"Video {vid}"),
            "published_at": v.get("published_at", ""),
            "thumbnail": v.get("thumbnail") or f"https://img.youtube.com/vi/{vid}/mqdefault.jpg",
            "url": v.get("url") or f"https://www.youtube.com/watch?v={vid}",
            "channel_title": v.get("channel_title", page.get("yt_channel_name", "")),
            "views": v.get("views", 0),
            "view_str": v.get("view_str", "Popular"),
            "status": status,
            "fb_post_id": fb_post_id,
            "error_message": error_msg,
            "is_in_queue": status in ("new", "queued", "downloaded"),
            "is_published": status == "published",
            "is_failed": status == "failed"
        })

    return enriched


def publish_single_video(page_id: int, video_id: str):
    """
    Manually downloads and publishes a specific video to Facebook on demand,
    then automatically deletes the local video file.
    """
    page = db.get_page_by_id(page_id)
    if not page:
        raise ValueError(f"Page ID {page_id} not found.")

    video = db.get_video_by_page_and_id(page_id, video_id)
    if not video:
        raise ValueError(f"Video {video_id} not found for page {page_id}.")

    title = video.get("title", f"Video {video_id}")
    auto_delete = bool(page.get("auto_delete_file", 1))
    local_path = None
    file_size_mb = 0.0

    try:
        log.info(f"[{page['page_name']}] On-Demand Downloading: {title} ({video_id})")
        db.update_video_status(page_id, video_id, "queued", error_message=None)
        
        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"],
            video_id=video_id,
            video_title=title,
            event_type="download",
            message=f"📥 Started download for '{title}' ({video_id})"
        )
        
        local_path = downloader.download_video(video_id)
        if os.path.exists(local_path):
            file_size_mb = round(os.path.getsize(local_path) / (1024 * 1024), 2)

        db.update_video_status(page_id, video_id, "downloaded", local_path=local_path, file_size_mb=file_size_mb, error_message=None)

        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"],
            video_id=video_id,
            video_title=title,
            event_type="upload",
            message=f"📤 Uploading '{title}' ({file_size_mb} MB) to Facebook Page '{page['page_name']}'..."
        )

        log.info(f"[{page['page_name']}] On-Demand Publishing to Facebook: {title}")
        fb_post_id = facebook_service.publish_video(
            local_path=local_path,
            title=title,
            page_id=page["fb_page_id"],
            access_token=page["fb_page_access_token"]
        )

        deleted_flag = 0
        if auto_delete and local_path and os.path.exists(local_path):
            try:
                os.remove(local_path)
                deleted_flag = 1
                log.info(f"[{page['page_name']}] Auto-deleted local video {video_id} ({file_size_mb} MB freed).")
            except Exception as del_err:
                log.warning(f"Could not delete temporary file {local_path}: {del_err}")

        db.update_video_status(
            page_id=page_id,
            video_id=video_id,
            status="published",
            fb_post_id=fb_post_id,
            error_message=None,
            file_size_mb=file_size_mb,
            deleted_after_upload=deleted_flag
        )

        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"],
            video_id=video_id,
            video_title=title,
            event_type="success",
            message=f"🚀 Published successfully to Facebook! Post ID: {fb_post_id} ({file_size_mb} MB freed)",
            details=f"https://facebook.com/{fb_post_id}"
        )

        return {"success": True, "fb_post_id": fb_post_id, "file_size_mb": file_size_mb}

    except Exception as e:
        log.error(f"[{page['page_name']}] On-demand publish failed for {video_id}: {e}")
        if auto_delete and local_path and os.path.exists(local_path):
            try:
                os.remove(local_path)
            except Exception:
                pass
        db.update_video_status(page_id, video_id, "failed", error_message=str(e))
        
        db.log_activity(
            page_id=page_id,
            page_name=page["page_name"],
            video_id=video_id,
            video_title=title,
            event_type="error",
            message=f"❌ Upload failed for '{title}': {str(e)}"
        )
        raise


def run_publish_cycle_for_page(page_id: int):
    """
    Downloads & publishes the next batch of queued videos for a specific Facebook Page,
    then automatically deletes the local video file to save disk space.
    """
    page = db.get_page_by_id(page_id)
    if not page:
        raise ValueError(f"Page ID {page_id} not found.")

    uploads_per_run = int(page.get("uploads_per_run", 1) or 1)
    auto_delete = bool(page.get("auto_delete_file", 1))

    pending = db.get_new_videos_for_page(page_id, limit=uploads_per_run)
    if not pending:
        log.info(f"No pending videos in queue for page '{page['page_name']}'.")
        return []

    db.log_activity(
        page_id=page_id,
        page_name=page["page_name"],
        event_type="info",
        message=f"▶ Starting publish batch of {len(pending)} video(s) for '{page['page_name']}'."
    )

    results = []
    for row in pending:
        video_id, title = row["video_id"], row["title"]
        local_path = None
        file_size_mb = 0.0

        try:
            log.info(f"[{page['page_name']}] Downloading: {title} ({video_id})")
            db.update_video_status(page_id, video_id, "queued", error_message=None)
            
            db.log_activity(
                page_id=page_id,
                page_name=page["page_name"],
                video_id=video_id,
                video_title=title,
                event_type="download",
                message=f"📥 Downloading '{title}'..."
            )
            
            local_path = downloader.download_video(video_id)
            if os.path.exists(local_path):
                file_size_mb = round(os.path.getsize(local_path) / (1024 * 1024), 2)

            db.update_video_status(page_id, video_id, "downloaded", local_path=local_path, file_size_mb=file_size_mb, error_message=None)

            db.log_activity(
                page_id=page_id,
                page_name=page["page_name"],
                video_id=video_id,
                video_title=title,
                event_type="upload",
                message=f"📤 Uploading '{title}' ({file_size_mb} MB) to Facebook..."
            )

            log.info(f"[{page['page_name']}] Publishing to Facebook Page '{page['page_name']}': {title}")
            fb_post_id = facebook_service.publish_video(
                local_path=local_path,
                title=title,
                page_id=page["fb_page_id"],
                access_token=page["fb_page_access_token"]
            )

            # AUTO STORAGE CLEANUP: Delete video file after publishing to avoid disk full issues
            deleted_flag = 0
            if auto_delete and local_path and os.path.exists(local_path):
                try:
                    os.remove(local_path)
                    deleted_flag = 1
                    log.info(f"[{page['page_name']}] Auto-deleted local video {video_id} ({file_size_mb} MB freed).")
                except Exception as del_err:
                    log.warning(f"Could not delete temporary file {local_path}: {del_err}")

            db.update_video_status(
                page_id=page_id,
                video_id=video_id,
                status="published",
                fb_post_id=fb_post_id,
                error_message=None,
                file_size_mb=file_size_mb,
                deleted_after_upload=deleted_flag
            )

            db.log_activity(
                page_id=page_id,
                page_name=page["page_name"],
                video_id=video_id,
                video_title=title,
                event_type="success",
                message=f"🚀 Published '{title}' to Facebook! Post ID: {fb_post_id} ({file_size_mb} MB saved)"
            )

            results.append({
                "page_id": page_id,
                "page_name": page["page_name"],
                "video_id": video_id,
                "title": title,
                "status": "published",
                "fb_post_id": fb_post_id,
                "file_size_mb": file_size_mb
            })
            log.info(f"[{page['page_name']}] Successfully published: {title} -> FB Post ID: {fb_post_id}")

        except Exception as e:
            log.error(f"[{page['page_name']}] Failed on {video_id}: {e}")
            # Clean up aborted download to prevent storage leak
            if auto_delete and local_path and os.path.exists(local_path):
                try:
                    os.remove(local_path)
                except Exception:
                    pass

            db.update_video_status(page_id, video_id, "failed", error_message=str(e))
            
            db.log_activity(
                page_id=page_id,
                page_name=page["page_name"],
                video_id=video_id,
                video_title=title,
                event_type="error",
                message=f"❌ Failed publishing '{title}': {str(e)}"
            )

            results.append({
                "page_id": page_id,
                "page_name": page["page_name"],
                "video_id": video_id,
                "title": title,
                "status": "failed",
                "error": str(e)
            })

    now = datetime.utcnow().isoformat()
    db.update_page(page_id, last_publish_at=now)
    return results



def sync_all_active_pages():
    """Syncs YouTube channels for all active pages."""
    pages = db.get_active_pages()
    summary = []
    for p in pages:
        try:
            total, new_count = sync_page_youtube(p["id"])
            summary.append({"page_id": p["id"], "page_name": p["page_name"], "total": total, "new": new_count, "success": True})
        except Exception as e:
            summary.append({"page_id": p["id"], "page_name": p["page_name"], "error": str(e), "success": False})
    return summary


def run_publish_cycle_all():
    """Runs publish cycle for all active pages."""
    pages = db.get_active_pages()
    all_results = []
    for p in pages:
        try:
            results = run_publish_cycle_for_page(p["id"])
            all_results.extend(results)
        except Exception as e:
            all_results.append({
                "page_id": p["id"],
                "page_name": p["page_name"],
                "status": "failed",
                "error": str(e)
            })
    return all_results


def clean_storage():
    """
    Purges all downloaded video and temporary files from the downloads directory.
    Returns the number of deleted files and total MB reclaimed.
    """
    download_dir = settings.get("DOWNLOAD_DIR", "./downloads")
    if not os.path.exists(download_dir):
        return {"deleted_count": 0, "reclaimed_mb": 0.0}

    files = glob.glob(os.path.join(download_dir, "*"))
    total_bytes = 0
    deleted_count = 0

    for f in files:
        if os.path.isfile(f):
            try:
                size = os.path.getsize(f)
                os.remove(f)
                total_bytes += size
                deleted_count += 1
            except Exception as e:
                log.warning(f"Could not remove {f}: {e}")

    reclaimed_mb = round(total_bytes / (1024 * 1024), 2)
    log.info(f"Storage purge complete: {deleted_count} files removed, {reclaimed_mb} MB reclaimed.")
    return {"deleted_count": deleted_count, "reclaimed_mb": reclaimed_mb}


def get_storage_usage():
    """
    Calculates current disk space consumed by downloads directory.
    """
    download_dir = settings.get("DOWNLOAD_DIR", "./downloads")
    if not os.path.exists(download_dir):
        return {"file_count": 0, "total_mb": 0.0, "download_dir": download_dir}

    files = glob.glob(os.path.join(download_dir, "*"))
    total_bytes = 0
    file_count = 0

    for f in files:
        if os.path.isfile(f):
            try:
                total_bytes += os.path.getsize(f)
                file_count += 1
            except Exception:
                pass

    return {
        "file_count": file_count,
        "total_mb": round(total_bytes / (1024 * 1024), 2),
        "download_dir": os.path.abspath(download_dir)
    }


# Backwards compatibility wrappers
def sync_youtube():
    pages = db.get_active_pages()
    if pages:
        return sync_page_youtube(pages[0]["id"])
    raise RuntimeError("No active Facebook page configured to sync.")


def run_publish_cycle():
    pages = db.get_active_pages()
    if pages:
        return run_publish_cycle_for_page(pages[0]["id"])
    raise RuntimeError("No active Facebook page configured.")
