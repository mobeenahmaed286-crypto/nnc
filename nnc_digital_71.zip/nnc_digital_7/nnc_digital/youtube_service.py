"""
Talks to the YouTube Data API v3 to list videos from specified YouTube channels.
Supports custom API Keys, Channel IDs, YouTube Handles (@handle), and Channel URLs.
"""
import re
import logging
import settings

# Suppress the harmless "file_cache is only supported with oauth2client<4.0.0" warning
logging.getLogger("googleapiclient.discovery_cache").setLevel(logging.ERROR)


def get_youtube_client(api_key: str = None):
    key = api_key or settings.get("YOUTUBE_API_KEY", "")
    if not key:
        raise RuntimeError("YouTube API Key not set. Add it in the global settings or page configuration.")
    from googleapiclient.discovery import build
    return build("youtube", "v3", developerKey=key)


def _client():
    return get_youtube_client()


def resolve_channel(channel_input: str, api_key: str = None) -> dict:
    """
    Given a channel ID, handle (@channel), or full YouTube URL,
    resolves the canonical Channel ID, Title, and Thumbnail using YouTube API.
    """
    clean_input = channel_input.strip()
    if not clean_input:
        raise ValueError("YouTube Channel input cannot be empty.")

    youtube = get_youtube_client(api_key)

    # 1. Direct Channel ID format: starts with UC and is ~24 chars
    if clean_input.startswith("UC") and len(clean_input) >= 20 and "/" not in clean_input:
        resp = youtube.channels().list(part="snippet,statistics", id=clean_input).execute()
        items = resp.get("items", [])
        if items:
            snippet = items[0]["snippet"]
            return {
                "channel_id": items[0]["id"],
                "channel_title": snippet.get("title", ""),
                "custom_url": snippet.get("customUrl", ""),
                "thumbnail": snippet.get("thumbnails", {}).get("default", {}).get("url", ""),
                "video_count": int(items[0].get("statistics", {}).get("videoCount", 0))
            }

    # 2. Extract Handle or ID from URL
    handle_match = re.search(r"@([a-zA-Z0-9_\-\.]+)", clean_input)
    channel_url_match = re.search(r"youtube\.com/channel/(UC[a-zA-Z0-9_\-]+)", clean_input)

    if channel_url_match:
        extracted_id = channel_url_match.group(1)
        resp = youtube.channels().list(part="snippet,statistics", id=extracted_id).execute()
        items = resp.get("items", [])
        if items:
            snippet = items[0]["snippet"]
            return {
                "channel_id": items[0]["id"],
                "channel_title": snippet.get("title", ""),
                "custom_url": snippet.get("customUrl", ""),
                "thumbnail": snippet.get("thumbnails", {}).get("default", {}).get("url", ""),
                "video_count": int(items[0].get("statistics", {}).get("videoCount", 0))
            }

    target_handle = None
    if handle_match:
        target_handle = handle_match.group(1)
    elif clean_input.startswith("@"):
        target_handle = clean_input.lstrip("@")

    if target_handle:
        try:
            resp = youtube.channels().list(part="snippet,statistics", forHandle=target_handle).execute()
            items = resp.get("items", [])
            if items:
                snippet = items[0]["snippet"]
                return {
                    "channel_id": items[0]["id"],
                    "channel_title": snippet.get("title", ""),
                    "custom_url": snippet.get("customUrl", ""),
                    "thumbnail": snippet.get("thumbnails", {}).get("default", {}).get("url", ""),
                    "video_count": int(items[0].get("statistics", {}).get("videoCount", 0))
                }
        except Exception:
            pass

    # 3. Fallback: Search by query
    resp = youtube.search().list(part="snippet", q=clean_input, type="channel", maxResults=1).execute()
    items = resp.get("items", [])
    if items:
        found_id = items[0]["snippet"]["channelId"]
        title = items[0]["snippet"].get("title", "")
        thumb = items[0]["snippet"].get("thumbnails", {}).get("default", {}).get("url", "")
        return {
            "channel_id": found_id,
            "channel_title": title,
            "custom_url": "",
            "thumbnail": thumb,
            "video_count": 0
        }

    # If all lookups fail but input looks like a channel ID, return as is
    return {
        "channel_id": clean_input,
        "channel_title": clean_input,
        "custom_url": "",
        "thumbnail": "",
        "video_count": 0
    }


def get_uploads_playlist_id(youtube, channel_id: str):
    resp = youtube.channels().list(part="contentDetails", id=channel_id).execute()
    items = resp.get("items", [])
    if not items:
        raise RuntimeError(f"YouTube Channel '{channel_id}' not found. Check Channel ID or API Key.")
    return items[0]["contentDetails"]["relatedPlaylists"]["uploads"]


def list_channel_videos(channel_id: str = None, api_key: str = None, max_results: int = 50):
    """Returns list of dicts: video_id, title, published_at, thumbnail, url — newest first."""
    cid = channel_id or settings.get("YOUTUBE_CHANNEL_ID")
    if not cid:
        raise RuntimeError("YouTube Channel ID not provided.")

    youtube = get_youtube_client(api_key)
    uploads_playlist_id = get_uploads_playlist_id(youtube, cid)

    videos = []
    next_page_token = None
    while len(videos) < max_results:
        resp = youtube.playlistItems().list(
            part="snippet",
            playlistId=uploads_playlist_id,
            maxResults=min(50, max_results - len(videos)),
            pageToken=next_page_token,
        ).execute()

        for item in resp.get("items", []):
            snippet = item["snippet"]
            # Ignore private or deleted videos
            if snippet.get("title") in ("Private video", "Deleted video"):
                continue
            res_id = snippet.get("resourceId", {})
            if res_id.get("kind") == "youtube#video" and res_id.get("videoId"):
                vid = res_id["videoId"]
                thumbs = snippet.get("thumbnails", {})
                thumb_url = (
                    thumbs.get("high", {}).get("url") or
                    thumbs.get("medium", {}).get("url") or
                    thumbs.get("default", {}).get("url") or
                    f"https://img.youtube.com/vi/{vid}/mqdefault.jpg"
                )
                videos.append({
                    "video_id": vid,
                    "title": snippet.get("title", "Untitled Video"),
                    "published_at": snippet.get("publishedAt", ""),
                    "thumbnail": thumb_url,
                    "url": f"https://www.youtube.com/watch?v={vid}",
                    "channel_title": snippet.get("channelTitle", "")
                })

        next_page_token = resp.get("nextPageToken")
        if not next_page_token:
            break

    return videos


def fetch_latest_channel_videos(channel_id: str = None, api_key: str = None, max_results: int = 10):
    """Fetches top N (default 10) latest videos directly from YouTube channel."""
    return list_channel_videos(channel_id=channel_id, api_key=api_key, max_results=max_results)


def fetch_popular_channel_videos(channel_id: str = None, api_key: str = None, max_results: int = 10):
    """
    Fetches the top N most popular / highest-viewed videos from the YouTube channel.
    Uses search API sorted by viewCount and attaches viewCount statistics.
    """
    cid = channel_id or settings.get("YOUTUBE_CHANNEL_ID")
    if not cid:
        raise RuntimeError("YouTube Channel ID not provided.")

    youtube = get_youtube_client(api_key)
    
    resp = youtube.search().list(
        part="snippet",
        channelId=cid,
        order="viewCount",
        type="video",
        maxResults=max_results
    ).execute()

    items = resp.get("items", [])
    video_ids = [it["id"]["videoId"] for it in items if it.get("id", {}).get("videoId")]

    # Fetch exact view counts from video statistics endpoint
    stats_map = {}
    if video_ids:
        try:
            stats_resp = youtube.videos().list(
                part="statistics",
                id=",".join(video_ids)
            ).execute()
            for v_item in stats_resp.get("items", []):
                v_id = v_item["id"]
                views = int(v_item.get("statistics", {}).get("viewCount", 0))
                stats_map[v_id] = views
        except Exception:
            pass

    videos = []
    for item in items:
        vid = item.get("id", {}).get("videoId")
        if not vid:
            continue
        snippet = item.get("snippet", {})
        thumbs = snippet.get("thumbnails", {})
        thumb_url = (
            thumbs.get("high", {}).get("url") or
            thumbs.get("medium", {}).get("url") or
            thumbs.get("default", {}).get("url") or
            f"https://img.youtube.com/vi/{vid}/mqdefault.jpg"
        )
        views = stats_map.get(vid, 0)
        
        if views >= 1_000_000:
            view_str = f"{views / 1_000_000:.1f}M views"
        elif views >= 1_000:
            view_str = f"{views / 1_000:.1f}K views"
        elif views > 0:
            view_str = f"{views:,} views"
        else:
            view_str = "Popular"

        videos.append({
            "video_id": vid,
            "title": snippet.get("title", "Untitled Video"),
            "published_at": snippet.get("publishedAt", ""),
            "thumbnail": thumb_url,
            "url": f"https://www.youtube.com/watch?v={vid}",
            "channel_title": snippet.get("channelTitle", ""),
            "views": views,
            "view_str": view_str
        })

    return videos


def channel_video_count(channel_id: str = None, api_key: str = None):
    """How many total videos exist on the channel."""
    cid = channel_id or settings.get("YOUTUBE_CHANNEL_ID")
    if not cid:
        return 0
    youtube = get_youtube_client(api_key)
    resp = youtube.channels().list(part="statistics", id=cid).execute()
    items = resp.get("items", [])
    if not items:
        return 0
    return int(items[0]["statistics"].get("videoCount", 0))


