"""
Multi-page automated scheduler:
Runs sync and publish cycles for each active Facebook Page according to its
independent schedule (daily, weekly, or specific AM/PM time slots).
"""
import time
import re
import logging
from datetime import datetime, timedelta

import db
import settings
import pipeline

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("nnc_scheduler")

CHECK_INTERVAL_SECONDS = 60
_last_run_map = {}  # maps (page_id, mode, slot, date/week) to boolean


def parse_single_time_slot(time_str: str):
    """
    Parses a time string in 12h (e.g. '09:00 AM', '2:30 pm') or 24h ('09:00', '14:30') format.
    Returns (hour_24, minute) or None if invalid.
    """
    s = time_str.strip().upper()
    if not s:
        return None

    # Check for AM/PM
    is_pm = "PM" in s
    is_am = "AM" in s
    clean_s = s.replace("AM", "").replace("PM", "").strip()

    parts = clean_s.split(":")
    if len(parts) != 2:
        return None

    try:
        hour = int(parts[0])
        minute = int(parts[1])
    except ValueError:
        return None

    if minute < 0 or minute > 59:
        return None

    if is_pm:
        if hour < 12:
            hour += 12
    elif is_am:
        if hour == 12:
            hour = 0
    else:
        # 24-hour format
        if hour < 0 or hour > 23:
            return None

    return hour, minute


def parse_time_slots(run_time_str: str) -> list:
    """
    Parses single or comma-separated time slots.
    Returns a list of (hour_24, minute) tuples. Defaults to [(9, 0)] if none valid.
    """
    if not run_time_str:
        return [(9, 0)]

    slots = []
    for raw in run_time_str.split(","):
        parsed = parse_single_time_slot(raw)
        if parsed:
            slots.append(parsed)

    return slots if slots else [(9, 0)]


def generate_daily_schedule_slots(posts_per_day: int = 1, post_gap_minutes: int = 120,
                                  start_time_str: str = "09:00 AM", end_time_str: str = "10:00 PM") -> list:
    """
    Generates dynamic (hour_24, minute) daily time slots based on posts_per_day,
    gap interval (minutes), and start/end time window.
    """
    posts_per_day = max(1, int(posts_per_day or 1))
    post_gap = max(15, int(post_gap_minutes or 120))
    
    start_parsed = parse_single_time_slot(start_time_str or "09:00 AM") or (9, 0)
    end_parsed = parse_single_time_slot(end_time_str or "10:00 PM") or (22, 0)

    start_mins = start_parsed[0] * 60 + start_parsed[1]
    end_mins = end_parsed[0] * 60 + end_parsed[1]
    
    if end_mins <= start_mins:
        end_mins = 23 * 60 + 59  # wrap until end of day

    slots = []
    current = start_mins
    for _ in range(posts_per_day):
        if current > end_mins:
            break
        h = (current // 60) % 24
        m = current % 60
        slots.append((h, m))
        current += post_gap

    return slots if slots else [start_parsed]


def parse_page_schedule_slots(page_dict) -> list:
    """
    Determines time slots for a page based on posts_per_day / post_gap_minutes or explicit run_time.
    """
    if isinstance(page_dict, dict):
        posts_per_day = int(page_dict.get("posts_per_day", 1) or 1)
        if posts_per_day > 1 and page_dict.get("post_gap_minutes"):
            return generate_daily_schedule_slots(
                posts_per_day=posts_per_day,
                post_gap_minutes=int(page_dict.get("post_gap_minutes", 120) or 120),
                start_time_str=page_dict.get("start_time", "09:00 AM"),
                end_time_str=page_dict.get("end_time", "10:00 PM")
            )
        return parse_time_slots(page_dict.get("run_time", "09:00 AM"))
    return parse_time_slots(str(page_dict or "09:00 AM"))


def format_time_display(run_time_str: str) -> str:
    """
    Converts stored time string to a clean 12-hour AM/PM display string.
    Example: '09:00,18:30' -> '09:00 AM, 06:30 PM'
    """
    slots = parse_time_slots(run_time_str)
    formatted = []
    for h, m in slots:
        period = "AM" if h < 12 else "PM"
        h12 = h % 12
        if h12 == 0:
            h12 = 12
        formatted.append(f"{h12:02d}:{m:02d} {period}")
    return ", ".join(formatted)


def calculate_next_run(page_or_time_str, mode: str = "daily") -> dict:
    """
    Calculates the exact next run datetime and human-readable time remaining.
    Accepts either a page dictionary or time string.
    """
    if isinstance(page_or_time_str, dict):
        page = page_or_time_str
        mode = page.get("upload_mode", "daily")
        slots = parse_page_schedule_slots(page)
        posts_count = int(page.get("posts_per_day", 1) or 1)
        if posts_count > 1:
            raw_slots_str = ", ".join([f"{h:02d}:{m:02d}" for h, m in slots])
            target_display = f"{posts_count} posts/day ({format_time_display(raw_slots_str)})"
        else:
            target_display = format_time_display(page.get("run_time", "09:00 AM"))
    else:
        slots = parse_time_slots(str(page_or_time_str or "09:00 AM"))
        target_display = format_time_display(str(page_or_time_str or "09:00 AM"))

    now = datetime.now()
    mode = (mode or "daily").lower()
    possible_runs = []

    if mode == "weekly":
        # Target day: Monday (weekday = 0)
        days_ahead = (0 - now.weekday()) % 7
        for h, m in slots:
            candidate = now.replace(hour=h, minute=m, second=0, microsecond=0) + timedelta(days=days_ahead)
            if candidate <= now:
                candidate += timedelta(days=7)
            possible_runs.append(candidate)
    else:
        # Daily mode
        for h, m in slots:
            candidate = now.replace(hour=h, minute=m, second=0, microsecond=0)
            if candidate <= now:
                candidate += timedelta(days=1)
            possible_runs.append(candidate)

    if not possible_runs:
        return {
            "next_run_iso": "",
            "next_run_formatted": "Scheduled",
            "time_remaining_str": "Pending",
            "target_time_display": target_display
        }

    next_dt = min(possible_runs)
    diff = next_dt - now
    total_seconds = int(diff.total_seconds())

    days = total_seconds // 86400
    hours = (total_seconds % 86400) // 3600
    mins = (total_seconds % 3600) // 60

    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    parts.append(f"{mins}m")
    time_remaining_str = f"in {' '.join(parts)}" if parts else "due now"

    # Friendly formatted next run
    if next_dt.date() == now.date():
        day_str = "Today"
    elif next_dt.date() == (now + timedelta(days=1)).date():
        day_str = "Tomorrow"
    else:
        day_str = next_dt.strftime("%a, %b %d")

    period = "AM" if next_dt.hour < 12 else "PM"
    h12 = next_dt.hour % 12
    if h12 == 0:
        h12 = 12
    time_str = f"{h12:02d}:{next_dt.minute:02d} {period}"

    return {
        "next_run_iso": next_dt.isoformat(),
        "next_run_formatted": f"{day_str} at {time_str}",
        "time_remaining_str": time_remaining_str,
        "target_time_display": target_display
    }



def _should_page_run_now(page: dict) -> bool:
    global _last_run_map
    page_id = page["id"]
    mode = page.get("upload_mode", "daily") or "daily"

    now = datetime.now()

    if mode == "weekly" and now.weekday() != 0:  # only Monday
        return False

    slots = parse_page_schedule_slots(page)

    # Check if any slot matches current hour and minute
    slot_matched = None
    for h, m in slots:
        if now.hour == h and now.minute == m:
            slot_matched = f"{h:02d}:{m:02d}"
            break

    if not slot_matched:
        return False

    run_key = f"{page_id}-{mode}-{slot_matched}-{now.date()}"
    if _last_run_map.get(run_key):
        return False  # already ran this slot today

    _last_run_map[run_key] = True
    return True


def check_and_execute_jobs():
    active_pages = db.get_active_pages()
    for page in active_pages:
        if _should_page_run_now(page):
            log.info(f"Triggering scheduled cycle for Page #{page['id']}: {page['page_name']}")
            db.log_activity(
                page_id=page["id"],
                page_name=page["page_name"],
                event_type="sync",
                message=f"⏰ Scheduled automation triggered for '{page['page_name']}'."
            )
            try:
                pipeline.sync_page_youtube(page["id"])
                pipeline.run_publish_cycle_for_page(page["id"])
                log.info(f"Completed scheduled cycle for Page #{page['id']}.")
            except Exception as e:
                log.error(f"Error executing scheduled job for Page #{page['id']}: {e}")
                db.log_activity(
                    page_id=page["id"],
                    page_name=page["page_name"],
                    event_type="error",
                    message=f"Scheduler error for '{page['page_name']}': {e}"
                )


if __name__ == "__main__":
    db.init_db()
    settings.init_settings_table()
    log.info("NNC Digital Multi-Page Scheduler running.")
    log.info("Checking active pages every minute against independent schedules.")

    try:
        while True:
            check_and_execute_jobs()
            time.sleep(CHECK_INTERVAL_SECONDS)
    except KeyboardInterrupt:
        log.info("Scheduler terminated by user.")

