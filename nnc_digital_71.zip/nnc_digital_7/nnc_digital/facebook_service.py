"""
Publishes local video files to Facebook Pages via the Meta Graph API.
Supports multi-page access tokens, automatic User-to-Page token resolution,
page validation, and detailed error diagnostics.
"""
import requests
import settings
import logging

GRAPH_VERSION = "v23.0"
log = logging.getLogger("nnc_facebook")


def list_pages(user_access_token: str):
    """
    Given a Facebook USER access token, fetch all Pages this user manages,
    along with each Page's own (long-lived) Page access token.
    Follows pagination (paging.next) so accounts with many pages all show up.
    """
    if not user_access_token.strip():
        raise ValueError("User Access Token is required.")

    url = f"https://graph.facebook.com/{GRAPH_VERSION}/me/accounts"
    params = {
        "fields": "id,name,access_token,category,picture{url}",
        "limit": 100,
        "access_token": user_access_token.strip(),
    }

    all_pages = []
    while url:
        resp = requests.get(url, params=params, timeout=30)
        data = resp.json()

        if not resp.ok or "error" in data:
            err = data.get("error", {})
            msg = err.get("message", f"HTTP {resp.status_code}")
            code = err.get("code", "")
            raise RuntimeError(f"Facebook Graph API Error ({code}): {msg}")

        for item in data.get("data", []):
            picture_url = item.get("picture", {}).get("data", {}).get("url", "")
            all_pages.append({
                "id": item.get("id"),
                "name": item.get("name", "Unnamed Page"),
                "access_token": item.get("access_token"),
                "category": item.get("category", "General"),
                "picture": picture_url
            })

        # Follow pagination
        next_url = data.get("paging", {}).get("next")
        url = next_url
        params = {}

    return all_pages


def resolve_page_token(page_id: str, token: str) -> str:
    """
    Automatically detects if the token is a User Access Token or a Page Access Token.
    If it is a User Token, queries Facebook Graph API to exchange/retrieve the actual
    Page Access Token required to publish videos without permission errors.
    """
    if not token or not page_id:
        return token

    token = token.strip()
    page_id = str(page_id).strip()

    try:
        # Check token identity via /me
        resp = requests.get(
            f"https://graph.facebook.com/{GRAPH_VERSION}/me",
            params={"fields": "id,name", "access_token": token},
            timeout=10
        )
        data = resp.json()
        if str(data.get("id")) == page_id:
            # Already a valid Page Access Token for this page
            return token

        # If User Token, fetch accounts and find this page's access_token
        acc_resp = requests.get(
            f"https://graph.facebook.com/{GRAPH_VERSION}/me/accounts",
            params={"fields": "id,name,access_token", "limit": 100, "access_token": token},
            timeout=15
        )
        acc_data = acc_resp.json()
        for item in acc_data.get("data", []):
            if str(item.get("id")) == page_id and item.get("access_token"):
                log.info(f"Auto-resolved User Token to Page Access Token for page {page_id} ('{item.get('name')}')")
                return item.get("access_token")

        # Try direct page access_token field query
        page_resp = requests.get(
            f"https://graph.facebook.com/{GRAPH_VERSION}/{page_id}",
            params={"fields": "id,name,access_token", "access_token": token},
            timeout=10
        )
        page_data = page_resp.json()
        if page_data.get("access_token"):
            return page_data.get("access_token")

    except Exception as e:
        log.warning(f"Could not auto-resolve page token: {e}")

    return token


def verify_page_access(page_id: str, access_token: str) -> dict:
    """
    Tests if a Page Access Token is valid and has video publishing capabilities.
    """
    if not page_id or not access_token:
        return {"valid": False, "error": "Page ID and Access Token are required."}

    effective_token = resolve_page_token(page_id, access_token)

    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{page_id.strip()}"
    params = {
        "fields": "id,name,link,picture{url}",
        "access_token": effective_token
    }

    try:
        resp = requests.get(url, params=params, timeout=15)
        data = resp.json()
        if "error" in data:
            return {"valid": False, "error": data["error"].get("message", "Invalid credentials.")}
        
        picture = data.get("picture", {}).get("data", {}).get("url", "")
        return {
            "valid": True,
            "id": data.get("id"),
            "name": data.get("name"),
            "picture": picture,
            "resolved_token": effective_token
        }
    except Exception as e:
        return {"valid": False, "error": str(e)}


def publish_video(local_path: str, title: str, page_id: str = None, access_token: str = None, description: str = "") -> str:
    """
    Uploads a video to the specified Facebook Page.
    Automatically ensures the correct Page Access Token is used.
    """
    fb_page_id = page_id or settings.get("FB_PAGE_ID")
    fb_token = access_token or settings.get("FB_PAGE_ACCESS_TOKEN")

    if not fb_page_id or not fb_token:
        raise RuntimeError("Facebook Page ID / Access Token not provided.")

    # Automatically resolve User Token -> Page Access Token to prevent (#100) No permission errors
    effective_token = resolve_page_token(fb_page_id, fb_token)

    url = f"https://graph-video.facebook.com/{GRAPH_VERSION}/{fb_page_id}/videos"

    with open(local_path, "rb") as f:
        files = {"source": f}
        data = {
            "access_token": effective_token,
            "title": title,
            "description": description or title,
        }
        resp = requests.post(url, files=files, data=data, timeout=600)

    result = resp.json()
    if "id" not in result:
        err = result.get("error", {})
        msg = err.get("message", str(result))
        code = err.get("code", "")
        raise RuntimeError(f"Facebook upload failed ({code}): {msg}")

    return result["id"]


def fetch_video_insights(page_id: str, access_token: str, fb_post_id: str) -> dict:
    """
    Fetches engagement metrics (views, reactions/likes, comments, shares) for a published video.
    """
    if not fb_post_id or not access_token:
        return {"views": 0, "likes": 0, "comments": 0, "shares": 0, "engagement_rate": 0.0}

    effective_token = resolve_page_token(page_id, access_token) if page_id else access_token
    url = f"https://graph.facebook.com/{GRAPH_VERSION}/{fb_post_id.strip()}"
    params = {
        "fields": "views,reactions.summary(total_count),comments.summary(total_count),shares",
        "access_token": effective_token
    }

    try:
        resp = requests.get(url, params=params, timeout=15)
        data = resp.json()
        if "error" in data:
            log.warning(f"Could not fetch insights for FB video {fb_post_id}: {data['error'].get('message')}")
            return {"views": 0, "likes": 0, "comments": 0, "shares": 0, "engagement_rate": 0.0}

        views = int(data.get("views", 0) or 0)
        likes = int(data.get("reactions", {}).get("summary", {}).get("total_count", 0) or 0)
        comments = int(data.get("comments", {}).get("summary", {}).get("total_count", 0) or 0)
        shares = int(data.get("shares", {}).get("count", 0) or 0)
        
        interactions = likes + comments + shares
        rate = round((interactions / max(views, 1)) * 100, 2)

        return {
            "views": views,
            "likes": likes,
            "comments": comments,
            "shares": shares,
            "engagement_rate": rate
        }
    except Exception as e:
        log.warning(f"FB insights request failed for {fb_post_id}: {e}")
        return {"views": 0, "likes": 0, "comments": 0, "shares": 0, "engagement_rate": 0.0}


def sync_page_video_metrics(page_id: int):
    """
    Synchronizes Facebook engagement metrics for all published videos on a page.
    """
    import db
    page = db.get_page_by_id(page_id)
    if not page:
        return 0

    published_videos = [v for v in db.get_page_videos(page_id) if v.get("status") == "published" and v.get("fb_post_id")]
    if not published_videos:
        return 0

    updated = 0
    for v in published_videos:
        metrics = fetch_video_insights(page["fb_page_id"], page["fb_page_access_token"], v["fb_post_id"])
        db.update_video_engagement(
            page_id=page_id,
            video_id=v["video_id"],
            views=metrics["views"],
            likes=metrics["likes"],
            comments=metrics["comments"],
            shares=metrics["shares"]
        )
        updated += 1

    return updated

