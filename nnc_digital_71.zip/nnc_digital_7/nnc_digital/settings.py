"""
Settings are stored in the SQLite DB so they can be edited live from the
dashboard (no need to hand-edit .env). On first run, .env values (if present)
are used as the initial defaults.
"""
import os
import db as _db

DEFAULT_KEYS = {
    "YOUTUBE_API_KEY": "",
    "YOUTUBE_CHANNEL_ID": "",
    "YOUTUBE_COOKIES": "",
    "FB_USER_ACCESS_TOKEN": "",
    "FB_PAGE_ID": "",
    "FB_PAGE_ACCESS_TOKEN": "",
    "FB_PAGE_NAME": "",
    "UPLOAD_MODE": "daily",
    "RUN_TIME": "09:00",
    "UPLOADS_PER_RUN": "1",
    "DOWNLOAD_DIR": "./downloads",
}


def init_settings_table():
    conn = _db.get_conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    conn.commit()

    # Seed with .env values (or defaults) only if not already set
    for key, default in DEFAULT_KEYS.items():
        existing = conn.execute("SELECT 1 FROM settings WHERE key=?", (key,)).fetchone()
        if not existing:
            value = os.getenv(key, default)
            conn.execute(
                "INSERT INTO settings (key, value) VALUES (?, ?)", (key, value)
            )
    conn.commit()
    conn.close()


def get(key, default=""):
    conn = _db.get_conn()
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    conn.close()
    if row and row["value"] not in (None, ""):
        return row["value"]
    return os.getenv(key, default)


def get_all():
    conn = _db.get_conn()
    rows = conn.execute("SELECT key, value FROM settings").fetchall()
    conn.close()
    return {r["key"]: r["value"] for r in rows}


def set_many(values: dict):
    conn = _db.get_conn()
    for key, value in values.items():
        conn.execute("""
            INSERT INTO settings (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
        """, (key, value))
    conn.commit()
    conn.close()
