"""
SQLite database layer for NNC Digital Multi-Page Management.
Handles:
- Multiple Facebook Pages / Pipelines
- Per-page video queue & publication tracking
- Storage tracking & cleanup state
- Automatic migration from legacy single-page schema
- Re-queue and re-scheduling capabilities
"""
import sqlite3
import os
from datetime import datetime

import sqlite3
import os
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.getenv("DB_PATH", "./nnc_digital.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    
    # 1. Create users table for multi-tenant authentication
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            page_limit INTEGER DEFAULT 5,
            is_active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    conn.commit()

    # 2. Create pages table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER DEFAULT 1,
            page_name TEXT NOT NULL,
            fb_page_id TEXT NOT NULL,
            fb_page_access_token TEXT NOT NULL,
            yt_channel_id TEXT NOT NULL,
            yt_channel_name TEXT DEFAULT '',
            yt_api_key TEXT DEFAULT '',
            upload_mode TEXT DEFAULT 'daily',
            run_time TEXT DEFAULT '09:00 AM',
            uploads_per_run INTEGER DEFAULT 1,
            posts_per_day INTEGER DEFAULT 1,
            post_gap_minutes INTEGER DEFAULT 120,
            start_time TEXT DEFAULT '09:00 AM',
            end_time TEXT DEFAULT '10:00 PM',
            auto_delete_file INTEGER DEFAULT 1,
            is_active INTEGER DEFAULT 1,
            last_sync_at TEXT,
            last_publish_at TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    conn.commit()

    # Add any missing columns to pages table if migrated from earlier schema
    page_cols = [c[1] for c in conn.execute("PRAGMA table_info(pages)").fetchall()]
    if "user_id" not in page_cols:
        conn.execute("ALTER TABLE pages ADD COLUMN user_id INTEGER DEFAULT 1")
    if "posts_per_day" not in page_cols:
        conn.execute("ALTER TABLE pages ADD COLUMN posts_per_day INTEGER DEFAULT 1")
    if "post_gap_minutes" not in page_cols:
        conn.execute("ALTER TABLE pages ADD COLUMN post_gap_minutes INTEGER DEFAULT 120")
    if "start_time" not in page_cols:
        conn.execute("ALTER TABLE pages ADD COLUMN start_time TEXT DEFAULT '09:00 AM'")
    if "end_time" not in page_cols:
        conn.execute("ALTER TABLE pages ADD COLUMN end_time TEXT DEFAULT '10:00 PM'")
    conn.commit()

    # 3. Create or migrate videos table
    table_info = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='videos'").fetchone()
    if table_info:
        sql = table_info[0]
        if "video_id TEXT PRIMARY KEY" in sql:
            conn.execute("ALTER TABLE videos RENAME TO videos_old")
            conn.execute("""
                CREATE TABLE videos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    page_id INTEGER DEFAULT 1,
                    video_id TEXT NOT NULL,
                    title TEXT,
                    published_at TEXT,
                    status TEXT DEFAULT 'new',
                    local_path TEXT,
                    fb_post_id TEXT,
                    error_message TEXT,
                    file_size_mb REAL DEFAULT 0,
                    deleted_after_upload INTEGER DEFAULT 1,
                    views INTEGER DEFAULT 0,
                    likes INTEGER DEFAULT 0,
                    comments INTEGER DEFAULT 0,
                    shares INTEGER DEFAULT 0,
                    engagement_rate REAL DEFAULT 0.0,
                    last_engagement_sync TEXT,
                    added_at TEXT,
                    updated_at TEXT,
                    UNIQUE(page_id, video_id)
                )
            """)
            conn.execute("""
                INSERT OR IGNORE INTO videos (
                    page_id, video_id, title, published_at, status, local_path,
                    fb_post_id, error_message, file_size_mb, deleted_after_upload, added_at, updated_at
                )
                SELECT 
                    COALESCE(page_id, 1), video_id, title, published_at, status, local_path,
                    fb_post_id, error_message, COALESCE(file_size_mb, 0), COALESCE(deleted_after_upload, 1),
                    added_at, updated_at 
                FROM videos_old
            """)
            conn.execute("DROP TABLE videos_old")
            conn.commit()
    else:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS videos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                page_id INTEGER DEFAULT 1,
                video_id TEXT NOT NULL,
                title TEXT,
                published_at TEXT,
                status TEXT DEFAULT 'new',
                local_path TEXT,
                fb_post_id TEXT,
                error_message TEXT,
                file_size_mb REAL DEFAULT 0,
                deleted_after_upload INTEGER DEFAULT 1,
                views INTEGER DEFAULT 0,
                likes INTEGER DEFAULT 0,
                comments INTEGER DEFAULT 0,
                shares INTEGER DEFAULT 0,
                engagement_rate REAL DEFAULT 0.0,
                last_engagement_sync TEXT,
                added_at TEXT,
                updated_at TEXT,
                UNIQUE(page_id, video_id)
            )
        """)
        conn.commit()

    # Add missing engagement columns to videos table if needed
    vid_cols = [c[1] for c in conn.execute("PRAGMA table_info(videos)").fetchall()]
    if "views" not in vid_cols:
        conn.execute("ALTER TABLE videos ADD COLUMN views INTEGER DEFAULT 0")
    if "likes" not in vid_cols:
        conn.execute("ALTER TABLE videos ADD COLUMN likes INTEGER DEFAULT 0")
    if "comments" not in vid_cols:
        conn.execute("ALTER TABLE videos ADD COLUMN comments INTEGER DEFAULT 0")
    if "shares" not in vid_cols:
        conn.execute("ALTER TABLE videos ADD COLUMN shares INTEGER DEFAULT 0")
    if "engagement_rate" not in vid_cols:
        conn.execute("ALTER TABLE videos ADD COLUMN engagement_rate REAL DEFAULT 0.0")
    if "last_engagement_sync" not in vid_cols:
        conn.execute("ALTER TABLE videos ADD COLUMN last_engagement_sync TEXT")
    conn.commit()

    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_videos_page_video ON videos(page_id, video_id)")
    conn.commit()

    # 4. Create activity_logs table
    conn.execute("""
        CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            page_id INTEGER,
            page_name TEXT,
            video_id TEXT,
            video_title TEXT,
            event_type TEXT NOT NULL,
            message TEXT NOT NULL,
            details TEXT,
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_activity_page_created ON activity_logs(page_id, created_at DESC)")
    conn.commit()

    # 5. Seed Default Admin & User Accounts + Migrate Existing Pages
    admin_row = conn.execute("SELECT * FROM users WHERE email = 'admin@nncdigital.com'").fetchone()
    if not admin_row:
        conn.execute("""
            INSERT INTO users (email, password_hash, name, role, page_limit, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 1, ?, ?)
        """, (
            "admin@nncdigital.com",
            generate_password_hash("12345678"),
            "Super Admin",
            "admin",
            9999,
            now,
            now
        ))
        conn.commit()

    ahmad_row = conn.execute("SELECT * FROM users WHERE email = 'ahmadraza@nncdigital.com'").fetchone()
    if not ahmad_row:
        cur = conn.execute("""
            INSERT INTO users (email, password_hash, name, role, page_limit, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 1, ?, ?)
        """, (
            "ahmadraza@nncdigital.com",
            generate_password_hash("123456"),
            "Ahmad Raza",
            "user",
            10,
            now,
            now
        ))
        ahmad_id = cur.lastrowid
        conn.commit()
    else:
        ahmad_id = ahmad_row["id"]

    # Shift all existing pages to ahmadraza@nncdigital.com
    conn.execute("UPDATE pages SET user_id = ? WHERE user_id IS NULL OR user_id = 0 OR user_id = 1", (ahmad_id,))
    conn.commit()

    conn.close()


# ==========================================
# USER MANAGEMENT & AUTHENTICATION
# ==========================================

def create_user(email: str, password: str, name: str, role: str = "user", page_limit: int = 5) -> int:
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    pwd_hash = generate_password_hash(password.strip())
    cur = conn.execute("""
        INSERT INTO users (email, password_hash, name, role, page_limit, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 1, ?, ?)
    """, (email.strip().lower(), pwd_hash, name.strip(), role.strip().lower(), int(page_limit), now, now))
    user_id = cur.lastrowid
    conn.commit()
    conn.close()
    return user_id


def get_user_by_email(email: str):
    if not email:
        return None
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE LOWER(email) = LOWER(?)", (email.strip(),)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_id(user_id: int):
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_all_users():
    conn = get_conn()
    rows = conn.execute("""
        SELECT u.*, COUNT(p.id) as pages_count 
        FROM users u 
        LEFT JOIN pages p ON p.user_id = u.id 
        GROUP BY u.id 
        ORDER BY u.id ASC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def verify_user_password(email: str, password: str):
    user = get_user_by_email(email)
    if not user:
        return None
    if not user.get("is_active", 1):
        return None
    if check_password_hash(user["password_hash"], password):
        return user
    return None


def update_user_password(user_id: int, new_password: str):
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    pwd_hash = generate_password_hash(new_password.strip())
    conn.execute("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?", (pwd_hash, now, user_id))
    conn.commit()
    conn.close()


def update_user_details(user_id: int, name: str = None, role: str = None, page_limit: int = None, is_active: int = None):
    conn = get_conn()
    updates = {}
    if name is not None:
        updates["name"] = name.strip()
    if role is not None:
        updates["role"] = role.strip().lower()
    if page_limit is not None:
        updates["page_limit"] = int(page_limit)
    if is_active is not None:
        updates["is_active"] = int(is_active)
    if updates:
        updates["updated_at"] = datetime.utcnow().isoformat()
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [user_id]
        conn.execute(f"UPDATE users SET {set_clause} WHERE id = ?", values)
        conn.commit()
    conn.close()


def delete_user(user_id: int):
    conn = get_conn()
    # Reassign pages to admin (user_id = 1) before deleting user
    admin = conn.execute("SELECT id FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1").fetchone()
    admin_id = admin["id"] if admin else 1
    conn.execute("UPDATE pages SET user_id = ? WHERE user_id = ?", (admin_id, user_id))
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()


def get_user_page_count(user_id: int) -> int:
    conn = get_conn()
    count = conn.execute("SELECT COUNT(*) as count FROM pages WHERE user_id = ?", (user_id,)).fetchone()["count"]
    conn.close()
    return count


def can_user_add_page(user_id: int) -> bool:
    user = get_user_by_id(user_id)
    if not user:
        return False
    if user.get("role") == "admin":
        return True
    limit = int(user.get("page_limit", 5))
    current_count = get_user_page_count(user_id)
    return current_count < limit


# ==========================================
# PAGE MANAGEMENT
# ==========================================

def get_all_pages(user_id: int = None):
    conn = get_conn()
    if user_id is not None:
        rows = conn.execute("SELECT * FROM pages WHERE user_id = ? ORDER BY id ASC", (user_id,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM pages ORDER BY id ASC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_active_pages(user_id: int = None):
    conn = get_conn()
    if user_id is not None:
        rows = conn.execute("SELECT * FROM pages WHERE is_active = 1 AND user_id = ? ORDER BY id ASC", (user_id,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM pages WHERE is_active = 1 ORDER BY id ASC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_page_by_id(page_id: int):
    conn = get_conn()
    row = conn.execute("SELECT * FROM pages WHERE id = ?", (page_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def add_page(page_name: str, fb_page_id: str, fb_page_access_token: str,
             yt_channel_id: str, yt_channel_name: str = "", yt_api_key: str = "",
             upload_mode: str = "daily", run_time: str = "09:00 AM",
             uploads_per_run: int = 1, auto_delete_file: int = 1,
             user_id: int = 1, posts_per_day: int = 1, post_gap_minutes: int = 120,
             start_time: str = "09:00 AM", end_time: str = "10:00 PM") -> int:
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    cur = conn.execute("""
        INSERT INTO pages (
            user_id, page_name, fb_page_id, fb_page_access_token, yt_channel_id,
            yt_channel_name, yt_api_key, upload_mode, run_time,
            uploads_per_run, posts_per_day, post_gap_minutes, start_time, end_time,
            auto_delete_file, is_active, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    """, (
        int(user_id),
        page_name.strip(),
        fb_page_id.strip(),
        fb_page_access_token.strip(),
        yt_channel_id.strip(),
        yt_channel_name.strip() or page_name.strip(),
        yt_api_key.strip(),
        upload_mode,
        run_time,
        int(uploads_per_run),
        int(posts_per_day),
        int(post_gap_minutes),
        start_time,
        end_time,
        int(auto_delete_file),
        now,
        now
    ))
    page_id = cur.lastrowid
    conn.commit()
    conn.close()
    return page_id


def update_page(page_id: int, **fields):
    if not fields:
        return
    conn = get_conn()
    fields["updated_at"] = datetime.utcnow().isoformat()
    set_clause = ", ".join([f"{k} = ?" for k in fields.keys()])
    values = list(fields.values()) + [page_id]
    conn.execute(f"UPDATE pages SET {set_clause} WHERE id = ?", values)
    conn.commit()
    conn.close()


def toggle_page_status(page_id: int):
    conn = get_conn()
    page = conn.execute("SELECT is_active FROM pages WHERE id = ?", (page_id,)).fetchone()
    if page:
        new_status = 0 if page["is_active"] == 1 else 1
        now = datetime.utcnow().isoformat()
        conn.execute("UPDATE pages SET is_active = ?, updated_at = ? WHERE id = ?", (new_status, now, page_id))
        conn.commit()
    conn.close()


def delete_page(page_id: int):
    conn = get_conn()
    conn.execute("DELETE FROM videos WHERE page_id = ?", (page_id,))
    conn.execute("DELETE FROM pages WHERE id = ?", (page_id,))
    conn.commit()
    conn.close()


# ==========================================
# VIDEO QUEUE & TRACKING
# ==========================================

def upsert_page_video(page_id: int, video_id: str, title: str, published_at: str):
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    conn.execute("""
        INSERT OR IGNORE INTO videos (page_id, video_id, title, published_at, status, added_at, updated_at)
        VALUES (?, ?, ?, ?, 'new', ?, ?)
    """, (page_id, video_id, title, published_at, now, now))
    conn.commit()
    conn.close()


def get_video_by_page_and_id(page_id: int, video_id: str):
    conn = get_conn()
    row = conn.execute("SELECT * FROM videos WHERE page_id = ? AND video_id = ?", (page_id, video_id)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_new_videos_for_page(page_id: int, limit: int = None):
    conn = get_conn()
    q = "SELECT * FROM videos WHERE page_id = ? AND status = 'new' ORDER BY published_at ASC"
    rows = conn.execute(q, (page_id,)).fetchall()
    conn.close()
    result = [dict(r) for r in rows]
    return result[:limit] if limit else result


def get_videos_for_page(page_id: int, status: str = None, limit: int = 100):
    conn = get_conn()
    if status and status != "all":
        q = "SELECT * FROM videos WHERE page_id = ? AND status = ? ORDER BY added_at DESC LIMIT ?"
        rows = conn.execute(q, (page_id, status, limit)).fetchall()
    else:
        q = "SELECT * FROM videos WHERE page_id = ? ORDER BY added_at DESC LIMIT ?"
        rows = conn.execute(q, (page_id, limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_videos(status: str = None, page_id: int = None, user_id: int = None, search: str = None, limit: int = 200):
    conn = get_conn()
    query = """
        SELECT v.*, p.page_name, p.fb_page_id as page_fb_id, p.user_id as page_user_id
        FROM videos v
        LEFT JOIN pages p ON v.page_id = p.id
        WHERE 1=1
    """
    params = []
    
    if user_id is not None:
        query += " AND p.user_id = ?"
        params.append(int(user_id))
        
    if page_id and str(page_id) != "all":
        query += " AND v.page_id = ?"
        params.append(int(page_id))
        
    if status and status != "all":
        query += " AND v.status = ?"
        params.append(status)
        
    if search:
        query += " AND (v.title LIKE ? OR v.video_id LIKE ?)"
        term = f"%{search.strip()}%"
        params.extend([term, term])
        
    query += " ORDER BY v.added_at DESC LIMIT ?"
    params.append(limit)
    
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_video_engagement(page_id: int, video_id: str, views: int = 0, likes: int = 0, comments: int = 0, shares: int = 0):
    """
    Updates Facebook engagement metrics (views, likes, comments, shares, engagement_rate)
    for a published video.
    """
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    total_interactions = (likes or 0) + (comments or 0) + (shares or 0)
    effective_views = max(views or 0, 1)
    rate = round((total_interactions / effective_views) * 100, 2)

    conn.execute("""
        UPDATE videos
        SET views = ?,
            likes = ?,
            comments = ?,
            shares = ?,
            engagement_rate = ?,
            last_engagement_sync = ?,
            updated_at = ?
        WHERE page_id = ? AND video_id = ?
    """, (int(views or 0), int(likes or 0), int(comments or 0), int(shares or 0), rate, now, now, page_id, video_id))
    conn.commit()
    conn.close()


def get_page_top_performing_videos(page_id: int, limit: int = 6):
    """
    Returns the top performing published videos for a specific page,
    sorted by total engagement (views + likes*2 + comments*3 + shares*4).
    """
    conn = get_conn()
    rows = conn.execute("""
        SELECT v.*, p.page_name,
               (COALESCE(v.views, 0) + (COALESCE(v.likes, 0) * 2) + (COALESCE(v.comments, 0) * 3) + (COALESCE(v.shares, 0) * 5)) as performance_score
        FROM videos v
        JOIN pages p ON v.page_id = p.id
        WHERE v.page_id = ? AND v.status = 'published'
        ORDER BY performance_score DESC, v.views DESC, v.added_at DESC
        LIMIT ?
    """, (page_id, limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_global_top_performing_videos(user_id: int = None, limit: int = 6):
    """
    Returns the top performing published videos across all pages (or user's pages).
    """
    conn = get_conn()
    if user_id is not None:
        rows = conn.execute("""
            SELECT v.*, p.page_name,
                   (COALESCE(v.views, 0) + (COALESCE(v.likes, 0) * 2) + (COALESCE(v.comments, 0) * 3) + (COALESCE(v.shares, 0) * 5)) as performance_score
            FROM videos v
            JOIN pages p ON v.page_id = p.id
            WHERE p.user_id = ? AND v.status = 'published'
            ORDER BY performance_score DESC, v.views DESC, v.added_at DESC
            LIMIT ?
        """, (user_id, limit)).fetchall()
    else:
        rows = conn.execute("""
            SELECT v.*, p.page_name,
                   (COALESCE(v.views, 0) + (COALESCE(v.likes, 0) * 2) + (COALESCE(v.comments, 0) * 3) + (COALESCE(v.shares, 0) * 5)) as performance_score
            FROM videos v
            JOIN pages p ON v.page_id = p.id
            WHERE v.status = 'published'
            ORDER BY performance_score DESC, v.views DESC, v.added_at DESC
            LIMIT ?
        """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]



def update_video_status(page_id: int, video_id: str, status: str, local_path: str = None,
                        fb_post_id: str = None, error_message: str = None,
                        file_size_mb: float = 0, deleted_after_upload: int = 1):
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    conn.execute("""
        UPDATE videos
        SET status = ?,
            local_path = COALESCE(?, local_path),
            fb_post_id = COALESCE(?, fb_post_id),
            error_message = ?,
            file_size_mb = CASE WHEN ? > 0 THEN ? ELSE file_size_mb END,
            deleted_after_upload = ?,
            updated_at = ?
        WHERE page_id = ? AND video_id = ?
    """, (status, local_path, fb_post_id, error_message, file_size_mb, file_size_mb, deleted_after_upload, now, page_id, video_id))
    conn.commit()
    conn.close()


# ==========================================
# RE-QUEUE & RESCHEDULE FUNCTIONS
# ==========================================

def requeue_video(page_id: int, video_id: str):
    """
    Reschedules an individual video by setting its status back to 'new'
    so it will be re-uploaded on the next cycle or on demand.
    """
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    conn.execute("""
        UPDATE videos
        SET status = 'new',
            error_message = NULL,
            fb_post_id = NULL,
            local_path = NULL,
            updated_at = ?
        WHERE page_id = ? AND video_id = ?
    """, (now, page_id, video_id))
    conn.commit()
    conn.close()


def requeue_all_page_videos(page_id: int, only_published: bool = False):
    """
    Reschedules all videos (or all published/failed videos) for a specific page
    so the entire catalog or batch can be uploaded again.
    """
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    if only_published:
        cur = conn.execute("""
            UPDATE videos
            SET status = 'new',
                error_message = NULL,
                fb_post_id = NULL,
                local_path = NULL,
                updated_at = ?
            WHERE page_id = ? AND status = 'published'
        """, (now, page_id))
    else:
        cur = conn.execute("""
            UPDATE videos
            SET status = 'new',
                error_message = NULL,
                fb_post_id = NULL,
                local_path = NULL,
                updated_at = ?
            WHERE page_id = ?
        """, (now, page_id))
    count = cur.rowcount
    conn.commit()
    conn.close()
    return count


def retry_failed_videos(page_id: int = None):
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    if page_id:
        cur = conn.execute("""
            UPDATE videos
            SET status = 'new', error_message = NULL, updated_at = ?
            WHERE page_id = ? AND status = 'failed'
        """, (now, page_id))
    else:
        cur = conn.execute("""
            UPDATE videos
            SET status = 'new', error_message = NULL, updated_at = ?
            WHERE status = 'failed'
        """, (now,))
    count = cur.rowcount
    conn.commit()
    conn.close()
    return count


# ==========================================
# METRICS & STATS HELPERS
# ==========================================

def get_page_stats(page_id: int):
    conn = get_conn()
    page = conn.execute("SELECT * FROM pages WHERE id = ?", (page_id,)).fetchone()
    if not page:
        conn.close()
        return None
        
    counts = conn.execute("""
        SELECT 
            COUNT(*) as tracked,
            SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published,
            SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
            SUM(CASE WHEN status IN ('queued', 'downloaded') THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN deleted_after_upload = 1 AND status = 'published' THEN file_size_mb ELSE 0 END) as storage_saved_mb
        FROM videos WHERE page_id = ?
    """, (page_id,)).fetchone()
    
    conn.close()
    return {
        "page": dict(page),
        "tracked": counts["tracked"] or 0,
        "published": counts["published"] or 0,
        "pending": counts["pending"] or 0,
        "failed": counts["failed"] or 0,
        "in_progress": counts["in_progress"] or 0,
        "storage_saved_mb": round(counts["storage_saved_mb"] or 0, 1)
    }


def get_global_stats():
    conn = get_conn()
    pages = conn.execute("SELECT * FROM pages").fetchall()
    counts = conn.execute("""
        SELECT 
            COUNT(*) as tracked,
            SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published,
            SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
            SUM(CASE WHEN status IN ('queued', 'downloaded') THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN deleted_after_upload = 1 AND status = 'published' THEN file_size_mb ELSE 0 END) as storage_saved_mb
        FROM videos
    """, ()).fetchone()
    conn.close()
    
    total_pages = len(pages)
    active_pages = len([p for p in pages if p["is_active"] == 1])
    
    # Calculate detailed stats for each page
    pages_with_stats = []
    for p in pages:
        p_dict = dict(p)
        stats = get_page_stats(p["id"])
        if stats:
            p_dict["stats"] = stats
        pages_with_stats.append(p_dict)
        
    return {
        "total_pages": total_pages,
        "active_pages": active_pages,
        "tracked": counts["tracked"] or 0,
        "published": counts["published"] or 0,
        "pending": counts["pending"] or 0,
        "failed": counts["failed"] or 0,
        "in_progress": counts["in_progress"] or 0,
        "storage_saved_mb": round(counts["storage_saved_mb"] or 0, 1),
        "pages": pages_with_stats
    }


# Backwards-compatible aliases
def all_videos():
    return get_all_videos()


def get_new_videos(limit=None):
    conn = get_conn()
    q = "SELECT * FROM videos WHERE status = 'new' ORDER BY published_at ASC"
    rows = conn.execute(q).fetchall()
    conn.close()
    result = [dict(r) for r in rows]
    return result[:limit] if limit else result


def update_status(video_id, status, local_path=None, fb_post_id=None, error_message=None):
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    conn.execute("""
        UPDATE videos
        SET status = ?,
            local_path = COALESCE(?, local_path),
            fb_post_id = COALESCE(?, fb_post_id),
            error_message = ?,
            updated_at = ?
        WHERE video_id = ?
    """, (status, local_path, fb_post_id, error_message, now, video_id))
    conn.commit()
    conn.close()


# ==========================================
# ACTIVITY & REAL-TIME EVENT LOGGING
# ==========================================

# In-memory recent events ring buffer for instantaneous live broadcast
_LIVE_EVENTS_BUFFER = []
_MAX_LIVE_BUFFER = 100

def log_activity(page_id: int = None, page_name: str = "", video_id: str = "",
                 video_title: str = "", event_type: str = "info",
                 message: str = "", details: str = ""):
    """
    Records an activity event into the database and pushes to the live in-memory buffer.
    event_type: 'sync', 'download', 'upload', 'success', 'error', 'info', 'queue'
    """
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    
    # Auto-resolve page_name if not provided but page_id is given
    if page_id and not page_name:
        p = conn.execute("SELECT page_name FROM pages WHERE id = ?", (page_id,)).fetchone()
        if p:
            page_name = p["page_name"]

    cur = conn.execute("""
        INSERT INTO activity_logs (page_id, page_name, video_id, video_title, event_type, message, details, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (page_id, page_name, video_id, video_title, event_type, message, details, now))
    log_id = cur.lastrowid
    conn.commit()
    conn.close()

    event_obj = {
        "id": log_id,
        "page_id": page_id,
        "page_name": page_name,
        "video_id": video_id,
        "video_title": video_title,
        "event_type": event_type,
        "message": message,
        "details": details,
        "created_at": now
    }
    
    global _LIVE_EVENTS_BUFFER
    _LIVE_EVENTS_BUFFER.insert(0, event_obj)
    if len(_LIVE_EVENTS_BUFFER) > _MAX_LIVE_BUFFER:
        _LIVE_EVENTS_BUFFER = _LIVE_EVENTS_BUFFER[:_MAX_LIVE_BUFFER]

    return event_obj


def get_recent_activity(page_id: int = None, limit: int = 50):
    """
    Returns recent activity logs ordered by newest first.
    """
    conn = get_conn()
    if page_id and str(page_id) != "all":
        rows = conn.execute("""
            SELECT * FROM activity_logs 
            WHERE page_id = ? 
            ORDER BY id DESC LIMIT ?
        """, (int(page_id), limit)).fetchall()
    else:
        rows = conn.execute("""
            SELECT * FROM activity_logs 
            ORDER BY id DESC LIMIT ?
        """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_live_events_buffer(page_id: int = None, limit: int = 30):
    """Returns in-memory live events buffer."""
    if page_id and str(page_id) != "all":
        return [e for e in _LIVE_EVENTS_BUFFER if e.get("page_id") == int(page_id)][:limit]
    return _LIVE_EVENTS_BUFFER[:limit]


def clear_activity_logs(page_id: int = None):
    """Clears activity logs from database."""
    conn = get_conn()
    if page_id:
        conn.execute("DELETE FROM activity_logs WHERE page_id = ?", (page_id,))
    else:
        conn.execute("DELETE FROM activity_logs")
    conn.commit()
    conn.close()
    
    global _LIVE_EVENTS_BUFFER
    if page_id:
        _LIVE_EVENTS_BUFFER = [e for e in _LIVE_EVENTS_BUFFER if e.get("page_id") != int(page_id)]
    else:
        _LIVE_EVENTS_BUFFER = []


def upsert_single_video(page_id: int, video_id: str, title: str, published_at: str) -> bool:
    """
    Explicitly adds or queues a single video for a page.
    Returns True if newly added, False if it was already existing.
    """
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    existing = conn.execute(
        "SELECT id, status FROM videos WHERE page_id = ? AND video_id = ?",
        (page_id, video_id)
    ).fetchone()
    
    is_new = False
    if not existing:
        conn.execute("""
            INSERT INTO videos (page_id, video_id, title, published_at, status, added_at, updated_at)
            VALUES (?, ?, ?, ?, 'new', ?, ?)
        """, (page_id, video_id, title, published_at, now, now))
        is_new = True
    elif existing["status"] not in ("new", "queued", "downloaded"):
        # If it was failed or published and user wants to re-queue it
        conn.execute("""
            UPDATE videos
            SET status = 'new', error_message = NULL, updated_at = ?
            WHERE page_id = ? AND video_id = ?
        """, (now, page_id, video_id))
        is_new = True
        
    conn.commit()
    conn.close()
    return is_new


def get_video_status_map(page_id: int, video_ids: list) -> dict:
    """
    Given a list of video_ids, returns a dictionary mapping video_id to its record info.
    """
    if not video_ids:
        return {}
    conn = get_conn()
    placeholders = ",".join(["?"] * len(video_ids))
    rows = conn.execute(f"""
        SELECT video_id, status, fb_post_id, error_message, file_size_mb, added_at, updated_at
        FROM videos
        WHERE page_id = ? AND video_id IN ({placeholders})
    """, [page_id] + list(video_ids)).fetchall()
    conn.close()
    return {r["video_id"]: dict(r) for r in rows}

