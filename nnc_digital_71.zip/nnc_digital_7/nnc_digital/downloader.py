"""
Downloads a video from YouTube using yt-dlp with intelligent client strategy
(Android client bypass, fallback to cookies for member-only/age-gated content).
"""
import os
import glob
import shutil
import tempfile
import logging
import yt_dlp
import settings

log = logging.getLogger("nnc_downloader")


def _get_cookiefile():
    """
    If the user has pasted YouTube cookies (Netscape format) into the
    Settings page, write them to a temp file for yt-dlp.
    """
    cookies_content = settings.get("YOUTUBE_COOKIES", "")
    if not cookies_content or not cookies_content.strip():
        return None
    path = os.path.join(tempfile.gettempdir(), "nnc_digital_yt_cookies.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(cookies_content.strip())
    return path


def download_video(video_id: str) -> str:
    """
    Downloads the YouTube video into the configured DOWNLOAD_DIR.
    Uses Android API client which reliably bypasses YouTube bot checks and 429 challenges.
    """
    download_dir = settings.get("DOWNLOAD_DIR", "./downloads")
    os.makedirs(download_dir, exist_ok=True)
    
    url = f"https://www.youtube.com/watch?v={video_id}"
    outtmpl = os.path.join(download_dir, f"{video_id}.%(ext)s")
    cookiefile = _get_cookiefile()

    # Priority strategies:
    # 1. Android client (works universally and bypasses web bot-check)
    # 2. Android client + Cookies (if sign-in is required)
    # 3. Web + Cookies fallback
    strategies = [
        {"client": ["android"], "use_cookie": False},
        {"client": ["android"], "use_cookie": True},
        {"client": ["android_creator"], "use_cookie": False},
        {"client": ["ios"], "use_cookie": False},
        {"client": None, "use_cookie": True if cookiefile else False},
        {"client": None, "use_cookie": False},
    ]

    last_error = None

    for strat in strategies:
        ydl_opts = {
            "outtmpl": outtmpl,
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "retries": 3,
            "fragment_retries": 3,
            "socket_timeout": 20,
            "ignoreerrors": False,
            "format": "best[ext=mp4]/best",
        }

        if shutil.which("ffmpeg"):
            ydl_opts["merge_output_format"] = "mp4"

        if strat["client"]:
            ydl_opts["extractor_args"] = {
                "youtube": {
                    "player_client": strat["client"]
                }
            }

        if strat["use_cookie"] and cookiefile and os.path.exists(cookiefile):
            ydl_opts["cookiefile"] = cookiefile

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])

            # Check if file was downloaded successfully
            expected_mp4 = os.path.join(download_dir, f"{video_id}.mp4")
            if os.path.exists(expected_mp4):
                return expected_mp4

            candidates = glob.glob(os.path.join(download_dir, f"{video_id}.*"))
            valid_files = [c for c in candidates if not c.endswith(".part") and not c.endswith(".ytdl")]
            if valid_files:
                return valid_files[0]

        except Exception as e:
            last_error = e
            continue

    error_msg = str(last_error) if last_error else "Unknown download error"
    raise RuntimeError(f"Download failed for video {video_id}: {error_msg}")
